<html>
<body>

<script>
var myVar = setInterval(myTimer, 1000);

function myTimer() {
    var d = new Date();
    document.getElementById("demo").innerHTML = d.toLocaleTimeString();
} 
  </script>
  <p id="demo"></p>
</body>
<html>