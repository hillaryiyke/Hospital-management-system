<?php session_start(); ?>
<?php
  //Connect to database whenever the page loads
    $con = mysql_connect("localhost", "root", "");
    if($con){
      echo "Successfully connected to database<br/>";
    }else{
      echo "Could not connect to database<br/>";
    }
    //Select database
    mysql_select_db("test");
?>

<?php
	/******************************/
	/*Set offline status*/
	$statusSql = "UPDATE fresh SET status = 0 WHERE username = '{$_SESSION['username']}'";
	$res = mysql_query($statusSql);
	/******************************/
	session_destroy();
	header("Refresh:0 url=nwelogin.php");
	exit;
?>
