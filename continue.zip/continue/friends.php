<?php session_start();?>
<html>
<head>
  <title>friends</title>
  <link rel="stylesheet" href="css/bootstrap.css">
</head>
<style>
   .jumbotron{
    padding-top: 10px;
     background: #2E2D88;
     height: 100px;
     color:white;
     font-size: 30px;
     text-align: center;
    }
</style>
   <body>
    <div class="container">
          <div class="jumbotron">
                <div class="btn-group">
                  <div class="navbar-brand"class="btn btn-md btn-primary">SMILE</div>
               <a href="friend.php" class="btn btn-md btn-primary">Profile</a>
                <a href="friends.php" class="btn btn-md btn-primary">Friends</a>
                <a href="logout.php" class="btn btn-md btn-primary">Log out</a>
                 </div>
               </div>
           <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <?php 
     $friend = $_GET['fr'];
      if(!file_exists("uploads/{$_SESSION['username']}.jpg")){
          echo "<span class='glyphicon glyphicon-user' style='font-size: 50px;'></span><br/>";
        }else{
          echo "<img src='uploads/{$_SESSION['username']}.jpg' alt='{$_SESSION['username']}' class='img-circle'  style='height:100px; width: 100px;'/><br/>";
        }
        //breaf comment for pix;
            
      echo "<br>FRIEND:" .$chat;
    echo "<div class='btn btn-default btn-danger' disable='disable'>";
      echo "Welcome, " . $_SESSION['username'] . "<br/>";
      echo"</div>";

      //Connect to database whenever the page loads
        $con = mysql_connect("localhost", "root", "");
        if($con){
        }else{
          echo "Could not connect to database<br/>";
        }
        //Select database
        mysql_select_db("test");
    ?>
          <hr/>
          <?php
            $sql = "SELECT * FROM fresh";
            $res = mysql_query($sql);
            echo "<ul>";
            while ($row = mysql_fetch_array($res)) {
              /*****************************************/
              $sqlCommentsNum = "SELECT * FROM comments WHERE reciver = '{$_SESSION['username']}' AND author = '{$row['username']}' AND viewStatus = 0";
              $resCommentsNum = mysql_query($sqlCommentsNum);
              $commentsNum = mysql_num_rows($resCommentsNum);
              if($commentsNum == 0){
                $count = "";
              }else{
                $count = "<span class='badge'>" . $commentsNum . "</span>" . "<span class='glyphicon glyphicon-envelope' style='font-size:16pt'></span>";
              }
              /*****************************************/
              if($row['username'] == $_SESSION['username']){
                continue;
              }
              echo "<li>";
              if(!file_exists("uploads/{$row['username']}.jpg")){
                echo "{$count} <a href='friend.php' span class='glyphicon glyphicon-user' style='font-size: 50px;'></a></span>";
          
              }else{
                echo "{$count} <a href='friend.php?fr={$row['username']}' ><img src='uploads/{$row['username']}.jpg' alt='{$row['username']}' class='img-circle'  style='height:50px; width: 50px;'/></a>";
              }
              echo "<a href='comment.php?fr={$row['username']}' style='font-size:25px;'>{$row['username']}</a>";
              /******************************/
              /*Check offline/online status*/
              if($row['status'] == 1){
                echo "<span class='glyphicon glyphicon-cd' style='color: orange;'></span>";
              }else{
                echo "<span class='glyphicon glyphicon-cd' style='color: green;'></span>";
              }
              /******************************/
               echo"<p />";
              echo "</li>";
            }
            echo "</ul>";
          ?>
        
    </div>
</body>
</html> 

<?php
  if($con){
    mysql_close();
  }
?>