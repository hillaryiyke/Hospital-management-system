<?php session_start();?>
<?php require_once("session.php"); ?>
<html>
<head>
<title></title>
<script type="text/javascript" src="Script.js"></script>
<link rel="stylesheet" href="css/bootstrap.css">
</head>
<style>
   .jumbotron{
    padding-top: 10px;
     background: #2E2D88;
     height: 100px;
     color:white;
     font-size: 30px;
    }
    .cont{
      text-align:left;
      color:white;
       background-color: #993399;
       padding-left: 40px;
       margin-left: 100px;
       margin-right: 7%;
       border-radius: 50px;
       margin-bottom: 3px;
    }
    .cool{
      text-align: left;
      color:white;
       background-color: #339999;
       padding-left: 40px;
       margin-right: 34%;
       border-radius: 50px;
    }
</style>
<body onload="gotoForm" >
  <div class="container text-center">
    <div class="jumbotron">
        <div class="btn-group">
            <div class="btn-group">
              <div class="navbar-brand"class="btn btn-md btn-primary">SMILE</div>
             <a href="friend.php" class="btn btn-md btn-primary">Profile<img src="hand.png" style="width:30px;"></a>
             <a href="friends.php" class="btn btn-md btn-primary">Friends<img src="com.png" style="width:30px;"></a>
             <a href="logout.php" class="btn btn-md btn-primary">Log out<img src="logout.png" style="width:30px;"></a>
           </div>
     </div>
      </div>
<?php
  /* function redirect($url = null){
    if($url != null){
      header("Location: " . $url);
      exit();
  }
  }
   
  if(!isset($_SESSION['username']) & !isset($_SESSION['password'])){
    redirect("index.php");
  }
*/
?>

<?php

$loggedUser = $_SESSION['username'];
echo "<div class='btn btn-default btn-dander' disable='disable'>";
echo "<br> Welcome," .$loggedUser."<br/>";
echo"</div>";
echo"</hr>";
$con = mysql_connect("localhost", "root", "");
if($con){
}else{
  echo "connection dont work";
}

mysql_select_db("test");
?>

<?php

  $friend = $_GET['fr'];
  echo "<br>FRIEND:" .$friend;

  /****************************************************/
  $sqlView = "UPDATE comments SET viewStatus = 1 WHERE author = '{$friend}' AND reciver = '{$loggedUser}' AND viewStatus = 0";
  $resView = mysql_query($sqlView);
  /****************************************************/

  if(isset($_POST['submit'])){
     $comments = trim(mysql_real_escape_string($_POST['comments']));
     if(!empty($comments)){
      $date_time = strftime("%d-%m-%y %H:%M:%S", (time() - 3600));

      //insert to db

        $sql = "INSERT INTO comments(author, comments, reciver, viewStatus, date_time) 
          VALUES('{$loggedUser}', '{$comments}', '{$friend}', 0, '{$date_time}')";
      
         // query statement
      $res = mysql_query($sql);
      if($res= mysql_affected_rows($con) == 1){
        echo "Sent";
      }else{
        echo "Not Sent"; 

      }
     }

  }
?>

      
      <?php
      //if(isset($_POST['submit'])){
        $sql = "SELECT * FROM comments WHERE (author = '{$loggedUser}' AND reciver = '{$friend}') OR (author = '{$friend}' AND reciver = '{$loggedUser}') ORDER BY id ASC";
          $res2 = mysql_query($sql);
          if(mysql_num_rows($res2) > 0){
            while($row = mysql_fetch_array($res2)){
              if($row['author'] == $loggedUser){
                echo "<div class='com1'>";
                //author
                echo "<div class='cont'>";
                echo "<span style='font-size: 15pt; color:pink'> {$row['author']}</span><br />";
                     //end of author
                     echo "<span style='font-size: 13pt;'> {$row['comments']}</span><br/>";
                echo "<span style='font-size: 9pt;'>{$row['date_time']}</span>";
                echo"<hr />";
                echo"</div>";

              }else{
                //author
                 echo "<div class='cool'>";
                echo "<span style='font-size: 15pt; color:blue'> {$row['author']}</span><br /></span>";
                     //end of author
                     echo "<span style='font-size: 13pt;'> {$row['comments']}</span><br/>";
                echo "<span style='font-size: 9pt;'>{$row['date_time']}</span>";
                echo"<hr />";
                  echo"</div>";
              }
            }
          }
      ?>
      <div id="formArea">
        <form action="#" method="POST">
          <textarea name="comments" class="form-control" rows="5" id="comment"></textarea><br/>
          <input type="submit" name="submit" class="btn btn-md btn-defualt" value="Send">
        </form>
      </div>
    </div>
</body>
<script type="text/javascript">
  window.onload = 
    function(){
      window.location = "#formArea";
    }
</script>
</html>

<?php
  if($con){
    mysql_close();
  }
?>