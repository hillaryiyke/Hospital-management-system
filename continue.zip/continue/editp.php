<?php session_start(); ?>
<?php

  //Connect to database whenever the page loads
  $con = mysql_connect("localhost", "root", "");
  if($con){
  }else{
    echo "Could not connect to database<br/>";
  }
  //Select database
  mysql_select_db("test");

?>

<?php
	if(isset($_POST['upload'])){
		$tmpName = $_FILES['file']['tmp_name'];
		$size = $_FILES['file']['size'];
		//Use the logged in username as the filename for the uploaded file
		$permanentName = "uploads/" . $_SESSION['username'];
		echo "ERROR: " . $_FILES['file']['error'];

		$target_file = "uploads" . basename($_FILES["file"]["name"]);
		$imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
		    echo "Sorry, only JPG, JPEG and PNG files are allowed.";
		    return;
		}

		if($_FILES['file']['error'] == 0){
			if(move_uploaded_file($tmpName, $permanentName . "." . $imageFileType)){
				echo "The file was uploaded successfully";
			}else{
				echo "File upload failed";
			}
		}
	}
?>

<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
	</head>
	<body>
		<?php echo "<h2>Welcome, {$_SESSION['username']}</h2>"; ?>
	<?php
	    $sql = "SELECT * FROM fresh WHERE username = '{$_SESSION['username']}'";
	    $res = mysql_query($sql);
	    echo "<div>";
	    while ($row = mysql_fetch_array($res)) {
	      if(!file_exists("uploads/{$_SESSION['username']}.jpg")){
	        echo "<span class='glyphicon glyphicon-user' style='font-size: 50px;'></span><br/>";
	      }else{
	        echo "<img src='uploads/{$_SESSION['username']}.jpg' alt='{$_SESSION['username']}' class='img-circle'  style='height:50px; width: 50px;'/><br/>";
	      }
	      $usn = $row['username'];
	      $em = $row['email'];
	    }
	    echo "</div>";
	?>
	<form action="editprofile.php" method="POST" enctype="multipart/form-data">
		<input type="hidden" value="10000000" name="MAX_FILE_SIZE">
		<input type="file" name="file"><br/>
		<input type="submit" name="upload" value="Upload">
	</form>

	<form action="editprofile.php" method="POST">
		<label for="username">Username:</label><br/>
		<input type="text" value="<?php echo $usn; ?>" name="username" id="username"><br/>
		<label for="email">Email:</label><br/>
		<input type="email" value="<?php echo $em; ?>" name="emal" id="email"><br/>
		<input type="submit" name="edit" value="Edit">
	</form>


	</body>
</html>
