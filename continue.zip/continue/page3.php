<?php session_start();?>


<html>
<head>
  <link rel="stylesheet" href="css/bootstrap.css">
   <script src="js/bootstrap.js"></script>
  <script src="js/jquery-1.11.3.min.js"></script>
</head>
<style>
  .jumbotron{
    margin-top: 0px;
    color:green;
    background-color: white;
  }
</style>
<body>
  <div class="container text-center">
      <div class="page-header">
        <div class="jumbotron">
          <div class="container text-center">
         <div class="jumbotron">
         <div class="header-page">
        <span style="font-size:40px; font-family: tahoma; color:green">Welcome to Smile In the word</span><br />
        </div>
         </div>
        This Platform Makes intaraction and communication easier 
       </div>
 <?php require_once("session.php"); ?>
<?php
  //Connect to database whenever the page loads
    $con = mysql_connect("localhost", "root", "");
    if($con){
      echo "";
    }else{
      echo "Could not connect to database";
    }
    //Select database
    mysql_select_db("test");


   
    $mypic = $_FILES['upload']['name'];
    $temp = $_FILES['upload']['tmp_name'];
    $type = $_FILES['upload']['type'];

  if(isset($_POST['submit'])){
    $fisrtname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
     $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
  
  if($password == $cpassword){
    //Hash the password
    $hashedPassword = md5($password);

   /* if(($type=="image/jpeg") || ($type=="image/jpg") ||($type=="image/bmp")){
  $directory = "./profiles/$username/images/";
  mkdir($directory, 0777, true);
  move_uploaded_file($temp, "profiles/$username/images/$mypic");

  echo"Profile<p><img border='1' width='100' height='100' src='profiles/$username/images/$mypic'><p>";
   */
    $sql = "INSERT INTO fresh(firstname, lastname, username, email, password)
     VALUES('{$fisrtname}', '{$lastname}', '{$username}', '{$email}', '{$hashedPassword}')";

    $res = mysql_query($sql);

    if(mysql_affected_rows($con) == 1){
      echo "Successfully registerd";
    }else{
      echo "Could not register the user";
    }

  }else{
    echo "Password do not match";
  }
}

?>


  	     <h4>Sign Up</h4>
  	       <form   class="form-inline "method="POST" action="page3.php">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input type="text" id="firstname"class="form-control" name="firstname" placeholder="First Name" required><br>
          </div>
             <p>  
             <div class="input-group">
               <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>  
              <input type="text" id="lastman" class="form-control" name="lastname" placeholder="Last Name" required><br>
            </div>
             <p>  
             <div class="input-group">
               <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>  
             <input type="text" id="username"class="form-control" name="username" placeholder="Username" required><br>
           </div>
             <p>         
              <div class="input-group">
                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
             	  <input type="email" id="email"class="form-control" name="email" placeholder="Email" required><br>
              </div>
             <p>         
               <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
             	  <input type="password" id="password" class="form-control" name="password" placeholder="Password" required><br>
              </div>
             <p>    
             <div class="input-group">
               <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>     
             	  <input type="password" id="password" class="form-control" name="cpassword" placeholder="Confirm Password" required><br>
              </div>
             <p />         
             	  <input type="submit" class="btn btn-danger" name="submit" value="Register">
             <p>         
  		     Already have an account?<a href="nwelogin.php">Login</a>
  		 </form>
 </div>
</body>
</html>
