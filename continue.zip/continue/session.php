<?php session_start(); ?>

<?php 

	function set_up_session($username = null, $password = null){
		if($username != null & $password != null){
			$_SESSION['username'] = $username;
			$_SESSION['password'] = $password;	
		}
	}

	function is_logged_in(){
		if(isset($_SESSION['username']) & isset($_SESSION['password'])){
			return true;
		}else{
			return false;
		}
	}
?>