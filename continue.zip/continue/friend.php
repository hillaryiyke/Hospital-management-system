<?php require_once("session.php");?>
 <html>
<head>
	<title>header</title>
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>
<style>
   .jumbotron{
    padding-top: 10px;
     background: #2E2D88;
     height: 100px;
     color:white;
     font-size: 30px;
     text-align: center;
    }
</style>
<body>
	<div class="container text-center">
	<div class="jumbotron">
    <div class="btn-group">
							<div class="btn-group">
              <div class="navbar-brand"class="btn btn-md btn-primary">SMILE</div>
           <a href="friend.php" class="btn btn-md btn-primary">Profile<img src="hand.png" style="width:30px;"></a>
            <a href="friends.php" class="btn btn-md btn-primary">Friends<img src="com.png" style="width:30px;"></a>
            <a href="logout.php" class="btn btn-md btn-primary">Log out<img src="logout.png" style="width:30px;"></a>
             </div>
           </div>
				    </div>
		
<?php
//Connect to database whenever the page loads
  $con = mysql_connect("localhost", "root", "");
  if($con){
  }else{
    echo "Could not connect to database<br/>";
  }
  //Select database
  mysql_select_db("test");

?>

			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		   <div class="thumbnail">
	<?php echo "<h2>Welcome, {$_SESSION['username']}</h2>"; ?>
		<?php
		    $sql = "SELECT * FROM fresh WHERE username = '{$_SESSION['username']}'";
		    $res = mysql_query($sql);
		    echo "<div>";
		    while ($row = mysql_fetch_array($res)) {
		      if(!file_exists("uploads/{$_SESSION['username']}.jpg")){
		        echo "<span class='glyphicon glyphicon-user' style='font-size: 50px;'></span><br/>";
		      }else{
		        echo "<img src='uploads/{$_SESSION['username']}.jpg' alt='{$_SESSION['username']}' class='img-circle'  style='height:100px; width: 100px;'/><br/>";
		      }
		      echo"<a href='logout.php'>Logout</a>";
		      echo"<p />";
		      echo " first Name: {$row['firstname']}<br/>";
		      echo"<p />";
		      echo "Name: {$row['username']}<br/>";
		      echo"<p />";
		      echo "Email: {$row['email']}<br/>";
		      echo"<p />";
		      echo "Last Name: {$row['lastname']}<br/>";
		      echo "";
		    }
		    echo "</div>";
		?>
	      <a href="editp.php">Update Your Profiles:</a>
	  </div>
	</div>
         
         <div class="col-lg-3 col-md-3 col-sm-2 col-xs-12">
         	<div class="thumbnail">
           <?php
	       if(!file_exists("uploads/{$_SESSION['username']}.jpg")){
		       echo "<span class='glyphicon glyphicon-user' style='font-size: 50px;'></span><br/>";
		    }else{
		        echo "<img src='uploads/{$_SESSION['username']}.jpg' alt='{$_SESSION['username']}' class='img-rounded'  style='height:200px; width: 200px;'/><br/>";
		    }
	      ?>
      </div>
</div>
</div>
</body>
</html>
