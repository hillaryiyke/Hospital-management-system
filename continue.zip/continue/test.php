<html>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" href="css/bootstrap.css">
	  <script src="js/bootstrap.js"></script>
<script src="js/jquery-1.11.3.min.js"></script>
<script>
$(document).ready(function(){
	$("#flip").click(function(){
   $("#panel").slideToggle("slow");

	});
});
</script>
</head>
<style>
    #panel,#flip{
    	padding: 5px;
    	text-align: center;
    	background-color:white;
    	border: solid 1px white; 
    }
    #panel{
    	padding: 50px;
    	display: none;

    }
    .jumbotron{
       background-color: white;
    }
</style>
<body>
	 <div class="container text-center">
	<div class="jumbotron">
        <div class="header-page">
	    	<span style="font-size:40px; font-family: tahoma; color:green">Welcome to Smile In the word</span><br />
	    	</div>
	    	This Platform Makes interaction and communication easier
       </div>
       <p />

       <img src="bestl.jpg" style='height:100px;'>

       <p />

	<div id="flip"><a href="#" style="font-family: tahoma; color:darkred">Click Here TO  View Terms And Condition</a> </div>
	<div id="flip"><a href="#" style="font-family: tahoma; color:darkred">This Social Media Is Made For Fast  And Instant Communication
  And Transmission    
      </div>  
	    

       <span style='color:green;'> Click On Continue Means You have Agreed On Our Terms And Condition<br /></span>
       <a href="nwelogin.php" class="btn btn-info btn-lg">CONTINUE</a>
	    </div>

      <?php
        $date = date("M/d/:i:s");

        echo "$date";

      ?>
      </div>
       
</body>
</html>