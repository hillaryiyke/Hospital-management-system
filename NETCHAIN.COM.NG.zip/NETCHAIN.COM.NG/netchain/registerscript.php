 <?php
           include'database.php';
        ?>
       
<?php
  $username = trim($_POST['username']);
  $firstname = trim($_POST['firstname']);
  $lastname = trim($_POST['lastname']);
  $email = trim($_POST['email']);
  $mobilenumber = trim($_POST['mobilenumber']);
  $bankname = trim($_POST['bankname']);
  $accountname = trim($_POST['accountname']);
  $accountnumber = trim($_POST['accountnumber']);
  $password = trim($_POST['password']);
  $password_confirmation = trim($_POST['password_confirmation']);

  if ($username && $firstname && $lastname && $email && $mobilenumber && $bankname && $accountname &&  $accountnumber && $password &&  $password_confirmation) {
     if (trim($_POST['password']) == trim($_POST['password_confirmation'])){
        
            $sql = mysql_query("SELECT username FROM user WHERE username = '{$username}'");
            $count = mysql_num_rows($sql);
            if ($count !=0) {
               echo '<span style="font-size:20px; color:red">'."username already exist choose another username!!".'</span>';
         }else{

             mysql_query("INSERT INTO user(username,firstname,lastname,email,mobilenumber,bankname,accountname,accountnumber,password) 
             VALUES('$username','$firstname','$lastname','$email','$mobilenumber','$bankname','$accountname','$accountnumber','$password')");
             
             echo "Successful registered";
           }
    }else{
      echo "Password mismatch";
    }
  }else{
    echo "empty files";
  }
?>