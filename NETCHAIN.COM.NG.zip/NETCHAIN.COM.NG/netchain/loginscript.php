<?php session_start();?>
<?php
   include_once'database.php';
?>
<?php
  $_SESSION['username'] = $_POST['username'];
  $_SESSION['password'] = $_POST['password'];
  if (empty($_SESSION['username'])) {
  	echo "Your username is required";
  }else{

  	if (empty($_SESSION['password'])) {
  		echo "password is required";
  	}else{
     
   $sql = "SELECT * FROM user WHERE username = '".$_SESSION['username']."' AND password = '".$_SESSION['password']."'";

        $res = mysql_query($sql);
         if(mysql_fetch_row($res) > 0){
             /******************************/
             //Redirect to user page
             header("Location:../netchin.com.ng/home2.php");
           }else{
           	header("Location:erropage.php");
           }
  	}
  }
  
 
?>