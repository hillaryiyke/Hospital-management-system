<?php 
  session_start();
?>
<?php

 $username = trim($_POST["username"]);
 $amount = trim($_POST["amount"]);
 
//Connect to database whenever the page loads
$con = mysqli_connect("localhost", "root", "", "netchaindatabase");
$sql = "SELECT * FROM adminsell WHERE username = '{$_SESSION['username']}'";
 $res = mysqli_query($con,$sql);
 if ($row = mysqli_fetch_array($res)){
 echo $row['amount'];
  }else{
    echo "0.00 NC";
  }
 
?> 