<?php
  
  //Connect to database whenever the page loads
    $con = mysql_connect("localhost", "root", "");
    if($con){
      echo "";
    }else{
      echo "Could not connect to database<br/>";
    }
    //Select database
    mysql_select_db("netchaindatabase");

?>