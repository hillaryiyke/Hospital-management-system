<?php

	session_start();
	session_unset();
	session_destroy();
    header("Location: ../netchin.com.ng/login.html");    
?>