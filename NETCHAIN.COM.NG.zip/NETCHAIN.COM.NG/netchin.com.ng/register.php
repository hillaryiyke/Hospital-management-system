<?php session_start();?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from profitchain.com/register by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Aug 2018 17:43:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="9F4WYdHwVGjFneAPqApiFSc2uBY6mpx6MbKdqqto">

    <title>Netchain</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com/">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/b4_sidebar.css">
    <link rel="stylesheet" href="css/navbar-top-fixed.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/signin.css">
    <link rel="shortcut icon" href="img/img_20180612_wa0012_xZm_icon.ico" type="image/x-icon">
    <!-- <link rel="stylesheet" href="https://profitchain.com/css/now-ui-dashboard.min.css"> -->
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-brand sidebarNavigation" data-sidebarClass="navbar-light bg-brand">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <!-- ProfitChain -->
                    <img src="img/pc4.jpg" alt="ProfitChain"height="30px">
                </a>
                <button class="navbar-toggler leftNavbarToggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto" >
                        <li class="nav-item">
                            <a class="nav-link" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="prices.html">All Prices</a>
                        </li>
                             <li class="nav-item">
                            <a class="nav-link" href="merchants.html">Merchants</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="questions.html">Questions/Answers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="terms-and-conditions.html">T&C</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://t.me/netchaingroup">Telegram group</a>
                        </li>

                        
                        <!-- Authentication Links -->
                                                    
                            <li>
                                <div class="btn-group">
                                    <a class="btn btn-success btn-main" href="login.html">Login</a>
                                    <a class="btn btn-success btn-main" href="register.html">Register</a>
                                </div>
                            </li>
                                            </ul>
                </div>
            </div>
        </nav>
    <div class="yes">
    <div class="body container-fluid">
    <form class="register" method="POST" action="register.php" aria-label="Register">
        <input type="hidden" name="_token" value="9F4WYdHwVGjFneAPqApiFSc2uBY6mpx6MbKdqqto">
        <h3 class="text-center text-brand">Sign Up</h3>
        <?php include '../netchain/registerscript.php';?>
        <h6 class="text-brand">Personal Details</h6>
        <div class="form-group row">
            <label for="firstname" class="col-md-6 col-form-label text-md-left">Username</label>

            <div class="col-md-12">
                <input id="username" type="text" class="form-control" name="username" value="" required autofocus>

                            </div>
        </div>

        <div class="form-group row">
            <label for="firstname" class="col-md-6 col-form-label text-md-left">Firstname</label>

            <div class="col-md-12">
                <input id="firstname" type="text" class="form-control" name="firstname" value="" required autofocus>

                            </div>
        </div>

        <div class="form-group row">
            <label for="lastname" class="col-md-6 col-form-label text-md-left">Lastname</label>

            <div class="col-md-12">
                <input id="lastname" type="text" class="form-control" name="lastname" value="" required autofocus>

                            </div>
        </div>

        <div class="form-group row">
            <label for="email" class="col-md-6 col-form-label text-md-left">E-Mail Address</label>

            <div class="col-md-12">
                <input id="email" type="email" class="form-control" name="email" value="" required>

                            </div>
        </div>

        <div class="form-group row">
            <label for="mobilenumber" class="col-md-6 col-form-label text-md-left">Mobile number</label>

            <div class="col-md-12">
                <input id="mobilenumber" type="number" class="form-control" name="mobilenumber" value="" required>

                            </div>
        </div>

        <hr class="">
        <h6 class="text-brand">Banking Details</h6>
        <div class="form-group row">
            <label for="bankname" class="col-md-6 col-form-label text-md-left">Bank name</label>

            <div class="col-md-12">
                <select name="bankname" id="bankname" class="form-control">
                    <option value="">---SELECT YOUR BANK---</option>
                    <option value="Access Bank">Access Bank</option>
                    <option value="Stanbic ibtc Bank">Stanbic ibtc Bank</option>
                    <option value="Diamond Bank">Diamond Bank</option>
                    <option value="Eco Bank">Eco Bank</option>
                    <option value="Fidelity Bank">Fidelity Bank</option>
                    <option value="First Bank">First Bank of Nigeria</option>
                    <option value="First City Monument Bank">First City Monument Bank</option>
                    <option value="Guarantee Trust Bank">Guarantee Trust Bank</option>
                    <option value="Sterling Bank">Sterling Bank</option>
                    <option value="Keystone Bank Limited">Keystone Bank Limited</option>
                    <option value="Skye Bank">Skye Bank</option>
                    <option value="Union Bank of Nigeria">Union Bank of Nigeria</option>
                    <option value="United Bank for Africa">United Bank for Africa</option>
                    <option value="Unity Bank Plc">Unity Bank Plc</option>
                    <option value="Wema Bank">Wema Bank</option>
                    <option value="Zenith Bank">Zenith Bank</option>
                </select>

                            </div>
        </div>
        <div class="form-group row">
            <label for="accountname" class="col-md-6 col-form-label text-md-left">Account name</label>

            <div class="col-md-12">
                <input id="accountname" type="text" class="form-control" name="accountname" value="" required autofocus>

                            </div>
        </div>

        <div class="form-group row">
            <label for="accountnumber" class="col-md-6 col-form-label text-md-left">Account number</label>

            <div class="col-md-12">
                <input id="accountnumber" type="number" class="form-control" name="accountnumber" value="" required autofocus>

           </div>
        </div>
        <hr>
        <h6 class="text-brand">Security Details</h6>
        <div class="form-group row">
            <label for="password" class="col-md-6 col-form-label text-md-left">Password</label>

            <div class="col-md-12">
                <input id="password" type="password" class="form-control" name="password" required>

       </div>
        </div>

        <div class="form-group row">
            <label for="password-confirm" class="col-md-6 col-form-label text-md-left">Confirm Password</label>

            <div class="col-md-12">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation"required>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-success">
                    Register
                </button>
            </div>
        </div>
    </form>
</div>
</div>
        <!-- Footer -->
	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-left text-md-left">
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Quick links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="index.html"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="contact-us.html"><i class="fa fa-angle-double-right"></i>Contact Us</a></li>
						<li><a href="questions.html"><i class="fa fa-angle-double-right"></i>Questions/Answers</a></li>
						<li><a href="login.html"><i class="fa fa-angle-double-right"></i>Get Started</a></li>
						<li><a href="merchants.html"><i class="fa fa-angle-double-right"></i>Merchants</a></li>
                                                

					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Help links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="responsible-trading.html"><i class="fa fa-angle-double-right"></i>Responsible trading</a></li>
						<li><a href="privacy-policy.html"><i class="fa fa-angle-double-right"></i>Privacy Policy</a></li>
						<li><a href="terms-and-conditions.html"><i class="fa fa-angle-double-right"></i>Terms and Conditions</a></li>
						<li><a href="prices.html"><i class="fa fa-angle-double-right"></i>Current Prices</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
                                        				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p class="h6 text-danger">2017-2018&copy All right Reserved.<a class="text-green ml-2" href="index.html" target="_blank">Profitchain.com</a></p>
				</div>
				</hr>
			</div>	
		</div>
	</section>
	<!-- ./Footer -->    </div>

    <!-- Scripts -->
    <script src="js/jquery-slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>    
    <script src="js/b4_sidebar.js"></script>
</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'a2plcpnl0775'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='../img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script>
<!-- Mirrored from profitchain.com/register by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Aug 2018 17:43:55 GMT -->
</html>
