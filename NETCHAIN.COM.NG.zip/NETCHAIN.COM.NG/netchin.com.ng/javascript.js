
var images = ["img/atm.jpg", "img/ATM2.jpg", "img/ATM3.jpg","img/ATM4.jpg" ,"img/ATM5.jpg"];
var imageNumber = 0
var imageLength = images.length -1;

function changeImage(){
	imageNumber ++;
	if (imageNumber > imageLength) {
		imageNumber = 0;
	}
	if (imageNumber < 0) {
		imageNumber = imageLength;
	}
	document.getElementById("image").src=images[imageNumber];
}
setInterval(changeImage, 3000);
