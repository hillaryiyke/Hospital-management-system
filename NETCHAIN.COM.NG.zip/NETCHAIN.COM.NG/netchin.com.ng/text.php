
<?//php include_once '../netchain/database.php';?>
<?php session_start();?>

<html>
<head>
	<title></title>
</head>
<style>
body{
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
}
li{
	list-style: none;
}
a{
	text-decoration: none;
}
.container{
	width: 60%;
	margin: 0 auto;
	overflow: auto;
}
header{
  border-bottom: 3px #fafafa solid ;
}
footer{
	 border-top: 3px #fafafa solid;
	 text-align: center;
	 padding-top: 5px;
}
.main{
	padding-bottom: 20px;
}
a.start{
	display: inline-block;
	color: #666;
	background: #4f4f4f;
	border:1px dotted #ccc;
	padding: 6px 13px;
}
.current{
	padding: 10px;
	background: #f4f4f4;
	border:#ccc dotted #ccc;
	margin: 20px 0 10px 0;
}
</style>
<body>
	<header>
		<div class="container">
			<h1>Class Quizz</h1>
		</div>
	</header>
	<main>
		<<?php

             $username = trim($_POST["username"]);
              $lastname = trim($_POST["lastname"]);

            //Connect to database whenever the page loads
            $con = mysqli_connect("localhost", "root", "", "netchaindatabase");
            $sql = "SELECT * FROM user WHERE username = '{$_SESSION['username']}'";
             $res = mysqli_query($con,$sql);
             while($row = mysqli_fetch_array($res)) {
               
              echo "<div class='aut'>";

              echo " <span>First_Name:<b style='color:white'; > {$row['firstname']}<b/><br/></span><hr/>";
             
              echo "<span>Last_name: <b style='color:white';>{$row['lastname']}<br/></span><hr/>";
            
              echo "<span>Department:<b style='color:white';> {$row['department']}<br/></span><hr/>";
            
              echo "<span>Reng_number:<b style='color:white';> {$row['reg']}<br/></span><hr/>";


               
             echo "</div>";
             }
             
            ?> 
		</div>
	</main>
	<footer>
		<div class="container">
			coppyright  &hillary 2018
		</div>
	</footer>
</body>
</html>