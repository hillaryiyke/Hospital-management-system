<?php session_start();?>
<?php
  session_start();
  if (!isset($_SESSION['username'])) {
    header("Location: member/login.php");
  }
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="C2NEFOaDzfaGvKXREwfotlnhvC1AP7LQIWu2P2Sr">

    <title>Netchain</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://profitchain.com/css/b4_sidebar.css">
    <link rel="stylesheet" href="css/navbar-top-fixed.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/signin.css">
    <link rel="shortcut icon" href="https://profitchain.com/img/img_20180612_wa0012_xZm_icon.ico" type="image/x-icon">
    <!-- <link rel="stylesheet" href="https://profitchain.com/css/now-ui-dashboard.min.css"> -->
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-dark sticky-top bg-brand sidebarNavigation" data-sidebarClass="navbar-light bg-brand">
            <div class="container-fluid">
                <a class="navbar-brand" href="home2.php">
                    <!-- ProfitChain -->
                    <img src="img/pc4.jpg" alt="ProfitChain"height="30px">
                </a>
                <button class="navbar-toggler leftNavbarToggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                            <strong style='font-size:25px'>Wallet:<?php include_once'../netchain/credited.php';?></strong>
                        </li>
                        </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto" >
                        <li class="nav-item">
                            <a class="nav-link" href="home2.php">Home</a>
                        </li>
                       
                             <li class="nav-item dropdown">
                                <a id="transactDrop" class="nav-link dropdown-toggle" role="button" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Buy/Sell/Transfer/Convert<span class="caret"></span> 
                                </a>
                                <div class="dropdown-menu" aria-labelledby="transactDrop">
                                    <a class="dropdown-item" href="sell.php">Sell Netchain</a>
                                    <a class="dropdown-item" href="buy.php">Buy Netchain</a>
                                    <a class="dropdown-item" href="conver.php">Convert to BTC/ETH/USD</a>
                                    <a class="dropdown-item" href="conver.php">Transfer Netchain</a>
                                    <a class="dropdown-item" href="account.php">Sales History</a>
                                </div>
                            </li>
                            
                        <li class="nav-item">
                            <a class="nav-link" href="https://t.me/netchaingroup">Telegram group</a>
                        </li>

                        
                        <!-- Authentication Links -->
                       
                  
                         <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                 <?php 
                                   include_once'../netchain/session.php';
                                  ?>
                                </a>
                               
                                   <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="account.php">Account</a>
                                    <a class="dropdown-item" href="../netchain/logout.php">
                                        Logout
                                    </a>
                                    <form id="logout-form" action="../netchain/logout.php" method="POST" style="display: none;">
                                        <input type="hidden" name="submit" value="C2NEFOaDzfaGvKXREwfotlnhvC1AP7LQIWu2P2Sr"> 
                                     </form>
                                  </div>
                            </li>
                     </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid main-landing" id="particles-js">
    <div class="row justify-content-center landing-2" style="background: url('https://profitchain.com/img/pasion.webp'); background-repeat: no-repeat; background-size: cover;">
        <div class="col-md-6 landing">
            <div class="">
                <center>
                    <span class="price-label">CURRENT PRICE</span><br> <span class="price">N15,000 per 1:Nc</span><br>
                    <hr>
                    <span class="price">$41.11 per 1:Nc</span>
                    <hr class="brand-hr"> </h6>
                    
                </center>
            </div>
        </div>
        <div class="col-md-6 landing">
            <center>
                <h5 class="text-center brand-label">Buy Netchain now<br>sell it at higher price on Saturday</h5>
                <hr class="brand-hr">
                <div>
                    <p>Netchain.com allow members to trade (buy and sell) Netchain that increases in value every saturday, the price of Netchain increases every saturday and it rarely decreases. if you buy Netchain worth N3000 today, the price would have increase to about N5000 or more by next saturday, you can now go ahead to sell your Netchain and receive sales payment within 48hours or less, you  can also convert your Netchain into currencies such as USD and Cryptos.</p>
                </div>
            </center>
        </div>
    </div>
</div>

<div class="container-fluid sub-main">
    <div class="row justify-content-center landing-3">
        <div class="col-md-6">
            <h4 class="work text-center">Best time to buy Netchain!.</h4>
            <p class="des text-center">
            The best time to buy your Nc is on saturday, Merchants are always sold out before the end of Sunday morning .
</p>
            
        </div>

        <div class="col-md-6">
            <h6 class="text-center work">Check the "All prices page" to see the full price list of Netchain.</h6>

            <div class="table table-responsive">
                <table class="table">
                    <thead>
                        <th>NC</th>
                        <th>Current Price</th>
                        <th>Expected Price</th>
                    </thead>
                    <tbody>
                           <tr>
                                <td>0.10</td>
                                <td>N 3000.00</td>
                                <td>N 4200.00</td>
                            </tr>
                            <tr>
                                <td>0.15</td>
                                <td>N 5000.00</td>
                                <td>N 7000.00</td>
                            </tr>
                            <tr>
                                <td>0.20</td>
                                <td>N 7000.00</td>
                                <td>N 9800.00</td>
                            </tr>
                                <tr>
                                <td>0.25</td>
                                <td>N 9000.00</td>
                                <td>N 12000.00</td>
                            </tr>
                                            </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
        <!-- Footer -->
	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-left text-md-left">
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>Quick links</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="home2.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						

					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
                <h5>Navigate account</h5>
					<ul class="list-unstyled quick-links">
                        <li><a href="account.php"><i class="fa fa-angle-double-right"></i>Profile</a></li>
                        <li><a href="buy.php"><i class="fa fa-angle-double-right"></i>Buy NC</a></li>
                        <li><a href="sell.php"><i class="fa fa-angle-double-right"></i>Sell NC</a></li>
                        <li><a href="conver.php"><i class="fa fa-angle-double-right"></i>Convert NC to ETH/BTC</a></li>
                    </ul>
                </div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p class="h6 text-danger">2017-2018&copy All right Reserved.<a class="text-green ml-2" href="/" target="_blank">Netchain.com.ng</a></p>
				</div>
				</hr>
			</div>	
		</div>
	</section>
	<!-- ./Footer -->    </div>

    <!-- Scripts -->
    <script src="js/jquery-slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>    
    <script src="https://profitchain.com/js/b4_sidebar.js"></script>
</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'a2plcpnl0775'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>
