<form id="paymentForm">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email-address" required />
    <br>
  </div>  
  <div class="form-group">
    <label for="amount">Amount</label>
    <input type="tel" id="amount" required />
    <br>
  </div>  
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" />
    <br>
  </div>  
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" />
    <br>
  </div>  
  <div class="form-submit">
    <button type="submit"> Pay </button> 
  </div>
</form>

<script type="text/javascript">

var paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);

function payWithPaystack(e) {
  e.preventDefault();
  var config = {
    key: 'pk_live_59d09c7893e6cb82b64de548db6d5f7dbb1a15af', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    firstname: document.getElementById("first-name").value,
    lastname: document.getElementById("first-name").value,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      var message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  };
  
  var paystackPopup = new Popup(config);
  paystackPopup.open();
}

</script>
<script type="text/javascript">
  <form action="/process" method="POST" >
  <script
    src="https://js.paystack.co/v1/inline.js" 
    data-key="pk_live_59d09c7893e6cb82b64de548db6d5f7dbb1a15af"
    data-email="customer@email.com"
    data-amount="10000"
    data-ref=<UNIQUE TRANSACTION REFERENCE>
  >
  </script>
</form>
</script>