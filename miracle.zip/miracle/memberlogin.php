<?php
session_start();
?>

<?php  include "db/connection.php";?>
 <?php
  if (isset($_POST['submit'])) {
   
    $_SESSION['card'] = $_POST['card'];
    $emailErr = $nameErr ="";
       
    $sql = "SELECT * FROM addrecod WHERE card = '{$_SESSION['card']}'";
      $res = mysql_query($sql);
       if(mysql_fetch_row($res) > 0){
           /******************************/
       //Redirect to user page
       header("Location: Member/prof.php");
     }else{
       $nameErr = "<span style='color:red; font-size:11px'>You dont have account yet please register or check your details</span>";
      
     } 

   }else{
    $nameErr = "";
   }
  ?>
  
    