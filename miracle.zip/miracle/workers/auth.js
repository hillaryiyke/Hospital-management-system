  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyAjrXgSRuaX7LWG_v4MvBLxZldFuPkbswo",
    authDomain: "patient-tracker-b3765.firebaseapp.com",
    databaseURL: "https://patient-tracker-b3765.firebaseio.com",
    projectId: "patient-tracker-b3765",
    storageBucket: "patient-tracker-b3765.appspot.com",
    messagingSenderId: "872615106368"
  };
  firebase.initializeApp(config);