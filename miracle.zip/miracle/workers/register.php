<!DOCTYPE HTML>
<html lang="en-US">

<!-- Mirrored from patient-tracker-b3765.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 24 Oct 2018 07:15:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<title>Sign up - Create a New Account! - Patient Tracker App</title>
	
	<script src="firebase.js"></script>
	<script type="text/javascript" src="auth.js"></script>
	<!--bootstrap-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<!--End of Bootsrap-->
    <link rel="stylesheet" href="style.css" />
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	<script src="sweetalert.min.js"></script>
	<link rel="stylesheet" href="../css/animate.min.css" />
  <script type="text/javascript" src="registerscript.js"></script>
	<style type="text/css">
     body {
     	margin:0;
     	font-family:Arial;
     	
     }
.top{
	background: url(../image/pg3.jpg);
     	background-repeat: no-repeat;
     	width: 100%;

}
     .topnav {
       overflow: hidden;
       background-color: green;
     }
      #img{
          	width: 100%;
          	
          }


     .topnav a {
       float: left;
       display: block;
       color: #f2f2f2;
       text-align: center;
       padding: 14px 16px;
       text-decoration: none;
       font-size: 17px;
     }

     .active {
       background-color: red;
       color: white;
     }

     .topnav .icon {
       display: none;
     }

     .dropdown {
         float: left;
         overflow: hidden;
     }

     .dropdown .dropbtn {
         font-size: 17px;    
         border: none;
         outline: none;
         color: white;
         padding: 14px 16px;
         background-color: inherit;
         font-family: inherit;
         margin: 0;
     }

     .dropdown-content {
         display: none;
         position: absolute;
         background-color: teal;
         min-width: 160px;
         box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
         z-index: 1;
     }

     .dropdown-content a {
         float: none;
         color: black;
         padding: 12px 16px;
         text-decoration: none;
         display: block;
         text-align: left;
     }

     .topnav a:hover, .dropdown:hover .dropbtn {
       background-color: #555;
       color: white;
     }

     .dropdown-content a:hover {
         background-color: #ddd;
         color: black;
     }

     .dropdown:hover .dropdown-content {
         display: block;
     }

     @media screen and (max-width: 600px) {
       .topnav a:not(:first-child), .dropdown .dropbtn {
         display: none;
       }
       .topnav a.icon {
         float: right;
         display: block;
       }
     }

     @media screen and (max-width: 600px) {
       .topnav.responsive {position: relative;}
       .topnav.responsive .icon {
         position: absolute;
         right: 0;
         top: 0;
       }
       .topnav.responsive a {
         float: none;
         display: block;
         text-align: left;
       }
       .topnav.responsive .dropdown {float: none;}
       .topnav.responsive .dropdown-content {position: relative;}
       .topnav.responsive .dropdown .dropbtn {
         display: block;
         width: 100%;
         text-align: left;
       }
     }
     .jumbotron li{
     	text-decoration: none;
     	display: inline;
     	margin: 8px;
     }
     .jumbotron li a:hover{
     	background: purple;
     }
     .cell a{
     	margin:8px;
     }
     .jumbotron{
     	background: #ccc;
     }
	</style>
</head>
<body>
	<!--Top navbar -->
<div class="topnav" id="myTopnav">
  <a href="#home" class="active">Home</a>
  <a href="#news">Manager</a>
  <a href="#contact">Patient room</a>
  <a href="#contact">pregnant</a>
  <a href="#contact">Contact us</a> 
  <a href="#about">About</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
	
	<!--end of Top Nav bar-->
	<div class="top">
	<div class="container-fluid">
	<div class="row">
		<div class="col-sm-4">
		
		</div>
		<div class="col-sm-4 ">
			<div class="sign-up animated fadeIn">
				<h3 class="app-heading" style="color:teal">POLY CLINIC HOSTPITAL</h3>
				<h3 class="text-center">Create Account</h3>
				<p class="text-center">Create your account Now. It hardly takes 30 Seconds</p>
        <?php include_once'registerscript.php';?>
				<div class="container-fluid">
				<div class="row">
          <form method="POST" name="myForm" onsubmit="return validateForm()" method="post" action="register.php">
    				<input type="text" class="col-xs-12  input-space form-control"  name="username" placeholder="Enter your Username" id="signup-username"/>
    				<input type="email" class="col-xs-12  input-space form-control" name="email" placeholder="Enter your Email" id="signup-email"/>
    				<input type="password" class="col-xs-12 input-space form-control"  name="pass" placeholder="Enter your Password" id="signup-password"/>
    				<input type="password" class="col-xs-12 input-space form-control"  name="pass2" placeholder="Repeat Password" id="signup-rpassword"/>
    				<input type="submit" class="col-xs-12 btn btn-mine btn-block input-space" value="Create Account" id="signup-btn" />
    				<div class="col-xs-12 text-center input-space"><a href="login.php">Already have an account?</a></div>
        </form>
				</div>
				</div>
				</div><!--end of form wrapper-->
			</div><!--end of col-md-4 --> 
	
		<div class="col-sm-4">
		
		</div>
		</div><!--end of row-->	
	</div>


	
	<script type="text/javascript" src="script.js"></script>
	</div>
</body>

<!-- Mirrored from patient-tracker-b3765.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 24 Oct 2018 07:15:27 GMT -->
</html>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

function validateForm(){
 var x = document.forms['myForm']["username"].value;
 var email = document.forms['myForm']["email"].value;
 var pass = document.forms['myForm']["pass"].value;
 var pass2 = document.forms['myForm']["pass2"].value;
   
   if (x== "") {
     alert("username required");
     return false;
   }

   if (email == "") {
    alert("Email required");
     return false;
   }

   if (pass == "") {
    alert("Pass required");
     return false;
   }

   if (pass2 == "") {
    alert("Repeat Password required");
     return false;
   }
    if (pass != pass2) {
    alert("password mismatch");
     return false;
   }
   /*if (isNaN(pass) || pass < 1 || pass > 10) {
     alert("Your password must contain 6 to 10 character");
     return false;
   }*/

}
</script>