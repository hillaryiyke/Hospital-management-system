
<?php

 include_once '../db/connection.php';
  $username = $_POST["username"];
  $email = $_POST['email'];
  $pass = $_POST['pass'];
  $pass2 = $_POST['pass2'];

   //if (isset($_POST["submit"])) {
  if ($username && $email &&  $pass && $pass2 ) {
    
  
   $sql = mysql_query("SELECT username FROM workers WHERE username = '{$username}'");
       $count = mysql_num_rows($sql);
       if ($count !=0) {
        echo '<span style="font-size:10px; color:red">'."username already exist choose another username!!".'</span>';
      
   }else{
    mysql_query("INSERT INTO workers (username,email,pass) VALUES('$username','$email','$pass')");
     echo "Your rgistration was successfully";
   }
  }else{
    echo "";
  }
  //}




?>