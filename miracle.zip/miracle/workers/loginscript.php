<?php  include "../db/connection.php";?>
 <?php
    $_SESSION['email'] = $_POST['email'];
    $_SESSION['pass'] = $_POST['pass'];
    $emailErr = $nameErr ="";
    if (empty($_SESSION['email'])) {
      // $nameErr = "Your username is required";
    }else{

       if (empty($_SESSION['pass'])) {
           // $emailErr = "E-mail is required";
       }else{
       
     $sql = "SELECT * FROM workers WHERE email = '".$_SESSION['email']."' AND pass = '".$_SESSION['pass']."'";
          $res = mysql_query($sql);
           if(mysql_fetch_row($res) > 0){
               /******************************/
               //Redirect to user page
               header("Location: ../Member/dashboard.php");
             }else{
               $nameErr = "<span style='color:red'>You dont have account yet please register or check your details</span>";
               //echo "You dont have account yet please register or check your details";
             }
       }
    }
    
   
  ?>