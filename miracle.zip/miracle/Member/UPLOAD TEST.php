<?php
  $image = "uploads/";
   $img_dir = $image.basename($_FILES["image"]["name"]);

   if (move_uploaded_file($_FILES["image"]["name"], $img_dir)) {
    
   }
?>
 <form method="POST" action=".php" ENCTYPE="multipart/form-data">
 	<input type="file" name="image">
 	<button type="submit" name="submit">UPLOAD</button>
</form>