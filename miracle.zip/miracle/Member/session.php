<?php
 if (!isset($_SESSION['patent_name'])) {
 	echo "Access denaid";
 }else{
 	echo "<h3>".$_SESSION['patent_name']."</h3>";
 }
?>