
<?php

 include_once '../db/connection.php';
  $msg ="";
  $patent_name = $_POST['patient_name'];
  $staus = $_POST['staus'];
  $housbamd_name = $_POST['housband_name'];
  $age = $_POST['age'];
  $appintment_date = $_POST['appintment_date'];
  $due_date = $_POST['due_date'];
  $medication = $_POST['medication'];
  $weight = $_POST['weight'];
  $growth = $_POST['growth'];
  $blood_group = $_POST['blood_group'];
  $blood_p = $_POST['blood_p'];
  $pulse_rate = $_POST['pulse_rate'];
  $suger = $_POST['suger'];
  $doctors_name = $_POST['doctors_name'];
   $card = $_POST['card'];
  
   //if (isset($_POST["submit"])) {
  //if ($username && $email &&  $pass && $pass2 ) {
    if (isset($_POST['submit'])) {
      
    
  //IMAGE UPLOAD
  $img_dir = "uploads/" .basename($_FILES["image"]["name"]);
   $image = $_FILES["image"]["name"];

   //$imageFileType = pathinfo($$img_dir,PATHINFO_EXTENSION);

   if (move_uploaded_file($_FILES["image"]["tmp_name"], $img_dir)) {
    echo "";
   }
  /* $sql = mysql_query("SELECT patient_name FROM addrecod WHERE patient_name = '{$patient_name}'");
       $count = mysql_num_rows($sql);
       if ($count !=0) {
        echo '<span style="font-size:10px; color:red">'."username already exist choose another patient_name!!".'</span>';*/
      
   //}else{
    mysql_query("INSERT INTO addrecod (patent_name,staus,housbamd_name,age,appintment_date,due_date,medication,weight,growth,blood_group,
      blood_p,pulse_rate,suger,doctors_name,card,image) 

      VALUES('$patent_name','$staus','$housbamd_name','$age','$appintment_date','$due_date','$medication','$weight','$growth','$blood_group','$blood_p','$pulse_rate','$suger','$doctors_name', '$image','$card')");

       $msg = "<span style='color:green;text-align:center; font-size:20px'>Your rgistration was successfully</span>";
  // }
  //}else{
    //echo "";
  ///}
  //}
}else{
  echo "";
}



?>