
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Dashboard - Patient Tracker App </title>
	<script src="../js/firebase.js"></script>
	<script type="text/javascript" src="auth.js"></script>
	<!--bootstrap-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<!--End of Bootsrap-->
    <link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="../css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"><body>
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	<script src="../js/sweetalert.min.js"></script>	
	<link rel="stylesheet" href="../css/animate.min.css" />
</head>
<style type="text/css">
     body {
     	margin:0;
     	font-family:Arial;

     	
     }
.top{
	background: url(../image/pg3.jpg);
     	background-repeat: no-repeat;
     	width: 100%;

}
     .topnav {
       overflow: hidden;
       background-color: green;
     }
      #img{
          	width: 100%;
          	
          }


     .topnav a {
       float: left;
       display: block;
       color: #f2f2f2;
       text-align: center;
       padding: 14px 16px;
       text-decoration: none;
       font-size: 17px;
     }

     .active {
       background-color: red;
       color: white;
     }

     .topnav .icon {
       display: none;
     }

     .dropdown {
         float: left;
         overflow: hidden;
     }

     .dropdown .dropbtn {
         font-size: 17px;    
         border: none;
         outline: none;
         color: white;
         padding: 14px 16px;
         background-color: inherit;
         font-family: inherit;
         margin: 0;
     }

     .dropdown-content {
         display: none;
         position: absolute;
         background-color: teal;
         min-width: 160px;
         box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
         z-index: 1;
     }

     .dropdown-content a {
         float: none;
         color: black;
         padding: 12px 16px;
         text-decoration: none;
         display: block;
         text-align: left;
     }

     .topnav a:hover, .dropdown:hover .dropbtn {
       background-color: #555;
       color: white;
     }

     .dropdown-content a:hover {
         background-color: #ddd;
         color: black;
     }

     .dropdown:hover .dropdown-content {
         display: block;
     }

     @media screen and (max-width: 600px) {
       .topnav a:not(:first-child), .dropdown .dropbtn {
         display: none;
       }
       .topnav a.icon {
         float: right;
         display: block;
       }
     }

     @media screen and (max-width: 600px) {
       .topnav.responsive {position: relative;}
       .topnav.responsive .icon {
         position: absolute;
         right: 0;
         top: 0;
       }
       .topnav.responsive a {
         float: none;
         display: block;
         text-align: left;
       }
       .topnav.responsive .dropdown {float: none;}
       .topnav.responsive .dropdown-content {position: relative;}
       .topnav.responsive .dropdown .dropbtn {
         display: block;
         width: 100%;
         text-align: left;
       }
     }
     .jumbotron li{
     	text-decoration: none;
     	display: inline;
     	margin: 8px;
     }
     .jumbotron li a:hover{
     	background: purple;
     }
     .cell a{
     	margin:8px;
     }
     .jumbotron{
     	background: #ccc;
     }
     .sell{
     	margin: 30px;
     	margin-left: 10px;
     	border: 1px solid green;
     	background: #ccc;
     }
     .col-sm-4{
     	margin: 10px;
     }
     .first{
     	background: red;
     	
     }
     .jumbotron{
     	background: teal;
     
     }
     .jumbotron a{
     	color: white;
     }
    h3{
      font-size: 25px;
      color: green;
     }
     
	</style>
<body>	
	<!--Top navbar -->
	<!--Top navbar -->
<div class="topnav" id="myTopnav">
  <a href="dashboard.php" class="active">Home</a>
      <a href="addrecords.php">Add Record</a>
      <a href="editerecords.php">Edit  Record</a> 
      <a href="search.php">Search  Record</a> 
      <a href="logout.php"><span class="btn btn-success" style="text-align:right">Logut</span></a> 
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<marquee><h3>Welcome to Poly clinic hospital</h3> </marquee>

	<!--end of Top Nav bar-->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-3">
			
			</div>
			<div class="col-sm-6">
				<h5 id="date-time">
				
				</h5>
			</div>
			<div class="col-sm-3">
			
			</div>
		</div>
	</div>
	<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
		
		</div>
		<div class="col-sm-8">
			<div class="box animated flipInX">
		
				<?php include_once 'time.html';?>
				<div class="container-fluid">
				<div class="row sell">
					<div class="">
						<div class="col-sm-4 jumbotron">
							<a href="addrecords.php">Add Records</a>
						</div>
				   </div>
					<p>
					<div class="col-sm-4 jumbotron">
						<a href="editsc2.php">Edit  Record</a>
					</div>
					<div class="col-sm-4 jumbotron">
						<a href="search.php">Search Record</a>
					</div>
				</div>
				</div>
			</div>
		</div>
		<div class="col-sm-2">
		
		</div>
		
    </div>
	</div> <!--end of main container-fluid-->
	
	<script type="text/javascript" src="script.js"></script>
	<script type="text/javascript">
		authenticationChecker();
		dashboard();
		dashboardDateTime('date-time');
	</script>
</body>
</html>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>