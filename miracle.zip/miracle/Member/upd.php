<?php session_start();?>
<?php
 include_once '../db/connection.php';
    if ($_POST) {
      $msg = "";
      $id = $_REQUEST['id'];
      $newpatient_name = $_REQUEST['newpatient_name'];
      $newstaus = $_REQUEST['newstaus'];
      $newhousband_name = $_REQUEST['newhousband_name'];
      $newage = $_REQUEST['newage'];
      $newappintment_date = $_REQUEST['newappintment_date'];
      $newdue_date = $_REQUEST['newdue_date'];
      $newmedication = $_REQUEST['newmedication'];
      $newweight = $_REQUEST['newweight'];
      $newgrowth = $_REQUEST['newgrowth'];

      $newblood_group = $_REQUEST['newblood_group'];
      $newblood_p = $_REQUEST['newblood_p'];
      $newpulse_rate = $_REQUEST['newpulse_rate'];
      $newsuger = $_REQUEST['newsuger'];
      $newdoctors_name = $_REQUEST['newdoctors_name'];
      $newcard = $_REQUEST['newcard'];
      
      
      

     $sql =  mysql_query("UPDATE addrecod SET patient_name='{$newpatient_name}', staus='{$newstaus}', housband_name='{$newhousband_name}' 
     	,age='{$newage}', appintment_date='{$newappintment_date}', due_date='{$newdue_date}', medication='{$newmedication}' ,
     	 weight='{$newweight}'
     	, growth='{$newgrowth}' , blood_group='{$newblood_group}' , blood_p='{$newblood_p}' , pulse_rate='{$newpulse_rate}' ,
     	 suger='{$newsuger}' , doctors_name='{$newdoctors_name}', card='{$newcard}' WHERE id='$id'");
     $res = mysql_query($sql);
    
      $msg = "You values have been updated successfully";
      
    }
    ?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Add New Record - POLY CLINIC HOUSPITAL</title>
<script src="../js/firebase.js"></script>
<script type="text/javascript" src="auth.js"></script>
<!--bootstrap-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src="../js/jquery.min.js"></script>
<script src="..//js/bootstrap.min.js"></script>
<!--End of Bootsrap-->
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="../css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"><body>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
<script src="../js/sweetalert.min.js"></script>	
<link rel="stylesheet" href="alertify.min.css" />
<script type="text/javascript" src="alertify.min.js"></script>
<link rel="stylesheet" href="../css/animate.min.css" />
</head>
	<style type="text/css">
     body {
     	margin:0;
     	font-family:Arial;
     	
     }
.top{
	background: url(../image/pg3.jpg);
     	background-repeat: no-repeat;
     	width: 100%;

}
     .topnav {
       overflow: hidden;
       background-color: green;
     }
      #img{
          	width: 100%;
          	
          }


     .topnav a {
       float: left;
       display: block;
       color: #f2f2f2;
       text-align: center;
       padding: 14px 16px;
       text-decoration: none;
       font-size: 17px;
     }

     .active {
       background-color: red;
       color: white;
     }

     .topnav .icon {
       display: none;
     }

     .dropdown {
         float: left;
         overflow: hidden;
     }

     .dropdown .dropbtn {
         font-size: 17px;    
         border: none;
         outline: none;
         color: white;
         padding: 14px 16px;
         background-color: inherit;
         font-family: inherit;
         margin: 0;
     }

     .dropdown-content {
         display: none;
         position: absolute;
         background-color: teal;
         min-width: 160px;
         box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
         z-index: 1;
     }

     .dropdown-content a {
         float: none;
         color: black;
         padding: 12px 16px;
         text-decoration: none;
         display: block;
         text-align: left;
     }

     .topnav a:hover, .dropdown:hover .dropbtn {
       background-color: #555;
       color: white;
     }

     .dropdown-content a:hover {
         background-color: #ddd;
         color: black;
     }

     .dropdown:hover .dropdown-content {
         display: block;
     }

     @media screen and (max-width: 600px) {
       .topnav a:not(:first-child), .dropdown .dropbtn {
         display: none;
       }
       .topnav a.icon {
         float: right;
         display: block;
       }
     }

     @media screen and (max-width: 600px) {
       .topnav.responsive {position: relative;}
       .topnav.responsive .icon {
         position: absolute;
         right: 0;
         top: 0;
       }
       .topnav.responsive a {
         float: none;
         display: block;
         text-align: left;
       }
       .topnav.responsive .dropdown {float: none;}
       .topnav.responsive .dropdown-content {position: relative;}
       .topnav.responsive .dropdown .dropbtn {
         display: block;
         width: 100%;
         text-align: left;
       }
     }
     .jumbotron li{
     	text-decoration: none;
     	display: inline;
     	margin: 8px;
     }
     .jumbotron li a:hover{
     	background: purple;
     }
     .cell a{
     	margin:8px;
     }
     .jumbotron{
     	background: #ccc;
     }
	</style>
<body>
<!--Top navbar -->
<div class="topnav" id="myTopnav">
   <a href="../workers.php" class="active">Home</a>
	  <a href="addrecords.php">Add Record</a>
	  <a href="editerecords.php">Edit  Record</a> 
	  <a href="search.php">Search  Record</a> 
	  <a href="logout.php"><span class="btn btn-success" style="text-align:right">Logut</span></a> 

  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<div class="container">
   <h4>UPADTE CLIENT WALLET:<?php echo $_REQUEST['username'];?> </h4>
   <?php echo $msg;?>
    <form method="POST" action="upd.php">
    	<table border="0" width="60%">
    		<div class="col-sm-6 form-group">
				<label for="add-name">Patient Name </label>
    		        <input type="text" name="newpatient_name" class="form-control" value="<?php echo $_REQUEST['patient_names'];?>">
    		</div>
    		<div class="col-sm-6 form-group">
    			<label for="add-blood" name="staus" >Marital status</label>
    			<select id="add-blood"  name="newstaus"  class="form-control" value="<?php echo $_REQUEST['stauss'];?>">
    				<option>Select</option>
    				<option>Marid</option>
    				<option>Single</option>
    				
    			</select>
    		</div>
            
             <div class="col-sm-6 form-group">
				<label for="add-name">housband_names </label>
                    <input type="text" name="newhousband_name"  class="form-control" value="<?php echo $_REQUEST['housband_names'];?>">
    		</div>
            
            <div class="col-sm-6 form-group">
				<label for="add-name">age </label>
    		        <input type="text" name="newage" class="form-control"  value="<?php echo $_REQUEST['ages'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">appintment_dates </label>
                     <input type="date" name="newappintment_date" class="form-control"  value="<?php echo $_REQUEST['appintment_dates'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">due_dates </label>
    		        <input type="text" name="newdue_date"  class="form-control" value="<?php echo $_REQUEST['due_dates'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">medications </label>
                   <input type="text" name="newmedication" class="form-control" value="<?php echo $_REQUEST['medications'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">weights </label>
    		        <input type="text" name="newweight" class="form-control" value="<?php echo $_REQUEST['weights'];?>">
    		</div>

             <div class="col-sm-6 form-group">
				<label for="add-name">growths </label>
    		        <input type="text" name="newgrowth" class="form-control" value="<?php echo $_REQUEST['growths'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-blood">Blood Group</label>
				<select  name="newblood_group" value="<?php echo $_REQUEST['blood_groups'];?>" class="form-control">
					<option>Select</option>
					<option>A+</option>
					<option>A-</option>
					<option>B+</option>
					<option>B-</option>
					<option>AB+</option>
					<option>AB-</option>
					<option>O+</option>
					<option>O-</option>
				</select>
			</div>


    		<div class="col-sm-6 form-group">
				<label for="add-name">blood_pressurep </label>
                    <input type="text" name="newblood_p" class="form-control" value="<?php echo $_REQUEST['blood_ps'];?>">
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">pulse_rate </label>
                    <input type="text" name="newpulse_rate" class="form-control" value="<?php echo $_REQUEST['pulse_rates'];?>"></td>
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">suger </label>
                    <input type="text" name="newsuger" class="form-control" value="<?php echo $_REQUEST['sugers'];?>">
             </div>

             <div class="col-sm-6 form-group">
				<label for="add-name">doctors_name </label>
                    <input type="text" name="newdoctors_name" class="form-control" value="<?php echo $_REQUEST['doctors_names'];?>"></td>
    		</div>

    		<div class="col-sm-6 form-group">
				<label for="add-name">card </label>
    		       <input type="text" name="newcard" class="form-control" value="<?php echo $_REQUEST['cards'];?>">
    		</div>


   </table>

    	   <button type="submit" class="btn btn-block btn-success">UPDATE AMOUNT</button>
    	   <input type="hidden" name="id" value="<?php echo $_REQUEST['ids'];?>">
      
 </form>
 </div>
</body>
</html>
	<script type="text/javascript">
		authenticationChecker();
		counterValue();
            function myFunction() {
                var x = document.getElementById("myTopnav");
                if (x.className === "topnav") {
                    x.className += " responsive";
                } else {
                    x.className = "topnav";
                }
            }
		function validateForm(){
		 var email =  document.forms["myForm"]["email"].value;
		 var pass = document.forms["myForm"]["pass"].value;

		 if(email == ""){
		  alert("email adress required");
		  return false;
		 }

		 if(pass == ""){
		  alert("password adress required");
		  return false;
		 }

		}
</script>