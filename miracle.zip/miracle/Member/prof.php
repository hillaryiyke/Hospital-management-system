<?php session_start();?>
 <!DOCTYPE HTML>
 <html lang="en-US">
 <head>
  <meta charset="UTF-8">
  <title>Add New Record - Patient Tracker App</title>
  <script src="../js/firebase.js"></script>
  <script type="text/javascript" src="auth.js"></script>
  <!--bootstrap-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
  <script src="..//js/bootstrap.min.js"></script>
  <!--End of Bootsrap-->
     <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="../css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"><body>
  <link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
  <script src="../js/sweetalert.min.js"></script> 
  <link rel="stylesheet" href="alertify.min.css" />
  <script type="text/javascript" src="alertify.min.js"></script>
  <link rel="stylesheet" href="../css/animate.min.css" />
  </head>
    <style type="text/css">
       body {
        margin:0;
        font-family:Arial;
        
       }
  .top{
    background: url(../image/pg3.jpg);
        background-repeat: no-repeat;
        width: 100%;

  }
       .topnav {
         overflow: hidden;
         background-color: green;
       }
        #img{
              width: 100%;
              
            }


       .topnav a {
         float: left;
         display: block;
         color: #f2f2f2;
         text-align: center;
         padding: 14px 16px;
         text-decoration: none;
         font-size: 17px;
       }

       .active {
         background-color: red;
         color: white;
       }

       .topnav .icon {
         display: none;
       }

       .dropdown {
           float: left;
           overflow: hidden;
       }

       .dropdown .dropbtn {
           font-size: 17px;    
           border: none;
           outline: none;
           color: white;
           padding: 14px 16px;
           background-color: inherit;
           font-family: inherit;
           margin: 0;
       }

       .dropdown-content {
           display: none;
           position: absolute;
           background-color: teal;
           min-width: 160px;
           box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
           z-index: 1;
       }

       .dropdown-content a {
           float: none;
           color: black;
           padding: 12px 16px;
           text-decoration: none;
           display: block;
           text-align: left;
       }

       .topnav a:hover, .dropdown:hover .dropbtn {
         background-color: #555;
         color: white;
       }

       .dropdown-content a:hover {
           background-color: #ddd;
           color: black;
       }

       .dropdown:hover .dropdown-content {
           display: block;
       }

       @media screen and (max-width: 600px) {
         .topnav a:not(:first-child), .dropdown .dropbtn {
           display: none;
         }
         .topnav a.icon {
           float: right;
           display: block;
         }
       }

       @media screen and (max-width: 600px) {
         .topnav.responsive {position: relative;}
         .topnav.responsive .icon {
           position: absolute;
           right: 0;
           top: 0;
         }
         .topnav.responsive a {
           float: none;
           display: block;
           text-align: left;
         }
         .topnav.responsive .dropdown {float: none;}
         .topnav.responsive .dropdown-content {position: relative;}
         .topnav.responsive .dropdown .dropbtn {
           display: block;
           width: 100%;
           text-align: left;
         }
       }
       .jumbotron li{
        text-decoration: none;
        display: inline;
        margin: 8px;
       }
       .jumbotron li a:hover{
        background: purple;
       }
       .cell a{
        margin:8px;
       }
       .jumbotron{
        background: #ccc;
       }
       .hed{
        background: #ccc;
        height: 50px;
        margin: 10px;
        font-size: 25px;
       }
       body{
        background: #ccc;
       }
    </style>
  <body>
  <!--Top navbar -->
  <div class="topnav" id="myTopnav">
   <a href="../workers.php" class="active">Home</a>
        <a href="addrecords.php">About us</a>
        <a href="editerecords.php">Contact us</a>  
    <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
  </div>
  
  <!--end of Top Nav bar-->
  <div class="container">
  <div class="add-form animated fadeIn">
  <h2 class="app-heading text-center">POLY CLINIC </h2>
  <h3 class="app-heading-dashboard text-center">Patients Records</h3>
  <div class="row">
      <center>
      <?php
      ///include 'session.php';

      $con = mysql_connect("localhost", "root", "");
      if ($con) { 
         echo "";
      }else{
        echo "cant connect";
      }
      mysql_select_db("polydb");
        $petent_name = $_POST['patient_name'];
          $sql = "SELECT * FROM addrecod WHERE card = '{$_SESSION['card']}'";
          $res = mysql_query($sql);
        ?>
        <?php while ($row = mysql_fetch_array($res)):;?>
        <div class="container">
          <div class="col-sm-12">
            <table class="table table-bordered">
               <thead >
                  <div class="hed">Patient History</div>
              </thead>

              <thead >
                  <?php
                  if (!file_exists("uploads/".$row["image"].".jpg")) {
                    echo "<span'>"."<img src='uploads/".$row["image"]."' class='img-block' style='height:200px; width: 200px;'>"."</span>"; 
                  }else{
                    echo "<span class='glyphicon glyphicon-user'class='img-circle' style='font-size: 50px;'></span><br/>";
                  }
                  ?>
              </thead>

              <thead>
                <tr>
                  <th>Card number</th>
                  <td><?php echo "{$row['card']}";?></td>
                </tr>

                <tr>
                  <th>Petient name</th>
                  <td><?php echo "{$row['patient_name']}";?></td>
                </tr>

                <tr>
                  <th>Housband name</th>
                  <td><?php echo "{$row['housband_name']}";?></td>
                </tr>

                <tr>
                  <th>Housband staus</th>
                  <td><?php echo "{$row['staus']}";?></td>
                </tr>

                <tr>
                  <th>Mdediction</th>
                  <td><?php echo "{$row['medication']}";?></td>
                </tr>

                <tr>
                  <th><HEAD>Age</HEAD></th>
                  <td><?php echo "{$row['age']}";?></td>
                </tr>

                <tr>
                  <th>Appointment Date</th>
                  <td><?php echo "{$row['appintment_date']}";?></td>
                </tr>

                <tr>
                  <th>Weight</th>
                  <td><?php echo "{$row['weight']}";?></td>
                </tr>

                <tr>
                  <th><HEAD>Growth</HEAD></th>
                  <td><?php echo "{$row['growth']}";?></td>
                </tr>

                <tr>
                  <th>Blood Group</th>
                  <td><?php echo "{$row['blood_group']}";?></td>
                </tr>
                <tr>
                  <th>Blood Pressure</th>
                  <td><?php echo "{$row['blood_p']}";?></td>
                </tr>

                <tr>
                  <th>Pulse Rate</th>
                  <td><?php echo "{$row['pulse_rate']}";?></td>
                </tr>

                <tr>
                  <th><HEAD>Suger</HEAD></th>
                  <td><?php echo "{$row['suger']}";?></td>
                </tr>

                <tr>
                  <th>Doctors Name</th>
                  <td><?php echo "{$row['doctors_name']}";?></td>
                </tr>

              </thead>
            </table>
        </div>
        </div>
  </div><!--end of row-->
  </div>
  </div> 
  <?php endwhile ;?>
</center>
 </body>
  <script type="text/javascript" src="script.js"></script>
  <script type="text/javascript">
    authenticationChecker();
    counterValue();
             function myFunction() {
                 var x = document.getElementById("myTopnav");
                 if (x.className === "topnav") {
                     x.className += " responsive";
                 } else {
                     x.className = "topnav";
                 }
             }
    function validateForm(){
     var email =  document.forms["myForm"]["email"].value;
     var pass = document.forms["myForm"]["pass"].value;

     if(email == ""){
      alert("email adress required");
      return false;
     }

     if(pass == ""){
      alert("password adress required");
      return false;
     }

    }
  </script>
 </html>