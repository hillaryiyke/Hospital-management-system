<?php
$id = $_POST['id'];
 $username = trim($_POST["username"]);
 $email = trim($_POST["email"]);
//Connect to database whenever the page loads
 include_once '../db/connection.php';
$sql = "SELECT * FROM addrecod";
 $res = mysql_query($sql);
 
 while ($row = mysql_fetch_array($res)){
 
  $id = $row['id'];
  $patient_name = $row['patient_name'];
  $staus = $row['staus'];
  $housband_name = $row['housband_name'];
  $age = $row['age'];
  $appintment_date = $row['appintment_date'];
  $due_date = $row['due_date'];
  $medication = $row['medication'];
  $weight = $row['weight'];
  $growth = $row['growth'];
  $blood_group = $row['blood_group'];
  $blood_p = $row['blood_p'];
  $pulse_rate = $row['pulse_rate'];
  $suger = $row['suger'];
  $doctors_name = $row['doctors_name'];
  $card = $row['card'];
   
   echo "<tr><td align=center>
       <a href=\"upd.php?ids=$id&patient_names=$patient_name&stauss=$staus&housband_names=$housband_name&ages=$age&appintment_dates
       =$appintment_date&due_dates=$due_date&medications=$medication&weights=$weight&growths=$growth&blood_groups=$blood_group&
       blood_ps=$blood_p&pulse_rates=$pulse_rate&sugers=$suger&doctors_names=$doctors_name&cards=$card\">$id</a></td>
       <td>$username</td><td>$amount</td>
   </tr>";
  }
 
?> 