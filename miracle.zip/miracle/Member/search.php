<?php
session_start();
?>

<?php  include "../db/connection.php";?>
 <?php
  if (isset($_POST['submit'])) {
   
    $_SESSION['card'] = $_POST['card'];
    $emailErr = $nameErr ="";
       
    $sql = "SELECT * FROM addrecod WHERE card = '{$_SESSION['card']}'";
      $res = mysql_query($sql);
       if(mysql_fetch_row($res) > 0){
           /******************************/
       //Redirect to user page
       header("Location: prof.php");
     }else{
       $nameErr = "<span style='color:red; font-size:11px'>You dont have account yet please register or check your details</span>";
      
     } 

   }else{
    $nameErr = "";
   }
  ?>
  
  <!DOCTYPE HTML>
  <html lang="en-US">
  <head>
  	<meta charset="UTF-8">
  	<title>Add New Record - Patient Tracker App</title>
  	<script src="../js/firebase.js"></script>
  	<script type="text/javascript" src="auth.js"></script>
  	<!--bootstrap-->
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="../css/bootstrap.min.css">
  	<script src="../js/jquery.min.js"></script>
  	<script src="..//js/bootstrap.min.js"></script>
  	<!--End of Bootsrap-->
      <link rel="stylesheet" href="style.css" />
  	<link rel="stylesheet" href="../css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"><body>
  	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
  	<script src="../js/sweetalert.min.js"></script>	
  	<link rel="stylesheet" href="alertify.min.css" />
  	<script type="text/javascript" src="alertify.min.js"></script>
  	<link rel="stylesheet" href="../css/animate.min.css" />
  	</head>
  		<style type="text/css">
  	     body {
  	     	margin:0;
  	     	font-family:Arial;
  	     	
  	     }
  	.top{
  		background: url(../image/pg3.jpg);
  	     	background-repeat: no-repeat;
  	     	width: 100%;

  	}
  	     .topnav {
  	       overflow: hidden;
  	       background-color: green;
  	     }
  	      #img{
  	          	width: 100%;
  	          	
  	          }


  	     .topnav a {
  	       float: left;
  	       display: block;
  	       color: #f2f2f2;
  	       text-align: center;
  	       padding: 14px 16px;
  	       text-decoration: none;
  	       font-size: 17px;
  	     }

  	     .active {
  	       background-color: red;
  	       color: white;
  	     }

  	     .topnav .icon {
  	       display: none;
  	     }

  	     .dropdown {
  	         float: left;
  	         overflow: hidden;
  	     }

  	     .dropdown .dropbtn {
  	         font-size: 17px;    
  	         border: none;
  	         outline: none;
  	         color: white;
  	         padding: 14px 16px;
  	         background-color: inherit;
  	         font-family: inherit;
  	         margin: 0;
  	     }

  	     .dropdown-content {
  	         display: none;
  	         position: absolute;
  	         background-color: teal;
  	         min-width: 160px;
  	         box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  	         z-index: 1;
  	     }

  	     .dropdown-content a {
  	         float: none;
  	         color: black;
  	         padding: 12px 16px;
  	         text-decoration: none;
  	         display: block;
  	         text-align: left;
  	     }

  	     .topnav a:hover, .dropdown:hover .dropbtn {
  	       background-color: #555;
  	       color: white;
  	     }

  	     .dropdown-content a:hover {
  	         background-color: #ddd;
  	         color: black;
  	     }

  	     .dropdown:hover .dropdown-content {
  	         display: block;
  	     }

  	     @media screen and (max-width: 600px) {
  	       .topnav a:not(:first-child), .dropdown .dropbtn {
  	         display: none;
  	       }
  	       .topnav a.icon {
  	         float: right;
  	         display: block;
  	       }
  	     }

  	     @media screen and (max-width: 600px) {
  	       .topnav.responsive {position: relative;}
  	       .topnav.responsive .icon {
  	         position: absolute;
  	         right: 0;
  	         top: 0;
  	       }
  	       .topnav.responsive a {
  	         float: none;
  	         display: block;
  	         text-align: left;
  	       }
  	       .topnav.responsive .dropdown {float: none;}
  	       .topnav.responsive .dropdown-content {position: relative;}
  	       .topnav.responsive .dropdown .dropbtn {
  	         display: block;
  	         width: 100%;
  	         text-align: left;
  	       }
  	     }
  	     .jumbotron li{
  	     	text-decoration: none;
  	     	display: inline;
  	     	margin: 8px;
  	     }
  	     .jumbotron li a:hover{
  	     	background: purple;
  	     }
  	     .cell a{
  	     	margin:8px;
  	     }
  	     .jumbotron{
  	     	background: #ccc;
  	     }
  	     .input-group input{
        margin: 20px;
  	     }
  	     
  	     .input-group button{
        margin: 20px;
  	     }
  	     body{
  	     	background: #CCC;
  	     }
  		</style>
  	<body>
  	<!--Top navbar -->
  	<div class="topnav" id="myTopnav">
  	  <a href="dashboard.php" class="active">Home</a>
  	   	  <a href="addrecords.php">Add Record</a>
  	   	  <a href="editerecords.php">Edit  Record</a> 
  	   	  <a href="search.php">Search  Record</a> 
          <a href="logout.php"><span class="btn btn-success" style="text-align:right">Logut</span></a> 

  	  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
  	</div>
	
	<!--end of Top Nav bar-->
	<div class="container-fluid search">
	<div class="row text-center">
		<div class="col-sm-3">
		
		</div>
		<div class="col-sm-6">
			<div class="delete-box animated fadeIn">
				<h2 class="app-heading">POLY CLINIC HOSPITAL</h2>
				<h3 class="app-heading">Search Patient's Record</h3>
					
					</div>
					<div class="row">
						<div class="col-sm-12" id='search-criteria' >
						<form  method="POST" name="myForm" class="form-inline" onsubmit="return validateForm()" action="search.php">
					       <div class="input-group">
					          <input id="card" type="text" class="form-control" name="card" placeholder="Enter your card number">
					          <button type="text" class="btn btn-info" name="submit" >Submit</button>
					       </div>
					       <br />
					       <?php echo $nameErr; ?>
					     </form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-sm-3">
		
		</div>
    </div> <!--end of Row-->
	</div> <!--end of main container-fluid-->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-3"></div>		
			<div class="col-sm-6">
			<div class="container-fluid" id="data" style="border:0px solid #ccc; height:350px; overflow:auto; margin-bottom:15px;">
			
			</div>		
			</div>
			<div class="col-sm-3"></div>		
		</div>
	</div>	

	<script type="text/javascript" src="script.js"></script>
	<script type="text/javascript">
		authenticationChecker();
	</script>
		<script type="text/javascript" src="script.js"></script>
		<script type="text/javascript">
			authenticationChecker();
			counterValue();
	            function myFunction() {
	                var x = document.getElementById("myTopnav");
	                if (x.className === "topnav") {
	                    x.className += " responsive";
	                } else {
	                    x.className = "topnav";
	                }
	            }
			function validateForm(){
			 var card =  document.forms["myForm"]["card"].value;
			
			 if(card == ""){
			  alert("Card  number  required");
			  return false;
			 }

			}
		</script>
</body>
</html>