<?php
//patent_nameinclude 'session.php';
session_start();
?>

<?php  include "../db/connection.php";?>
 <?php 
    $sql = "SELECT * FROM addrecod WHERE patent_name = '{$_SESSION['patent_name']}'";
      $res = mysql_query($sql);
      while ($row = mysql_fetch_array($res)) {
        echo "{$row['card']}";

       
    }
      
     
    
  
    
   
  ?>
 
