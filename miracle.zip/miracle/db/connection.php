<?php
  
$con = mysql_connect("localhost", "root", "");

if ($con) {
	echo "";
}else{
	echo "cant connect to db";
}

mysql_select_db("polydb");

?>