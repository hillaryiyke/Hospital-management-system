var image = ["image/pg1.jpg", "image/pg2.jpg","image/pg3.jpg"];

var imgNumber = 0
var imgLength = image.length -1;

function imageSlide(){
   imgNumber ++;
   if (imgNumber > imgLength) {
     imgNumber = 0;

   }
	if (imgNumber < 0 ) {
	  imgNumber = imgLength;

    }
  document.getElementById("img").src= image[imgNumber];
}
 setInterval(imageSlide, 3000);