// Offset for Site Navigation
$('#siteNav').affix({
	offset: {
		top: 100
	}
})