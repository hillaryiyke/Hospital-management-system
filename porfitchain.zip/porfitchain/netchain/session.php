<?php session_start(); ?>

<?php 
if (!isset($_SESSION['username'])) {
	echo "access denaid";
	exit();
}else{
	echo '<span style="color:tomato">'.$_SESSION['username']. '</span>';
}


?>