<?php
   session_start();
?>
<?php
   include_once'database.php';
?>


<html>
<header>
	<title></title>
	<link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/b4_sidebar.css">
    <link rel="stylesheet" href="../css/navbar-top-fixed.css">
    <link rel="stylesheet" href="../profitchain.com/css/custom.css">
    <link rel="stylesheet" href="../profitchain.com/css/signin.css">
</header>
<style>
   li {
    display: inline-block;
    background: 8px;
   }
   .menu{
    background: teal;
   }
   li a{
    color: white;
    margin: 8px;
   
   }
   a{
     text-decoration: none;
   }
   a:hover{
    background:tomato;
   }
   .jumbotron{
    background: yellow;
    color: white;
   }

</style>
<body>
	<center>
		<div class="menu">
		 <h4 class="jumbotron">DMIN SELLS NETCHAIN</h4>
		  <li><a href="adminsell.php">Adminsell</a></li>
		  <li><a href="upadate.php">User list of account</a></li>
		     <li><a href="selectnetchainbuy.php">All bought netchain</a></li>
         <form id="logout-form" action="adminlogout.php" method="POST">
            <input type="hidden" name="submit" value=""> 
            <button type="submit" name="submit">Logout</button>
         </form>
		</div>
		<p>
		 <p>
		<?php
		if ($_POST) {
		  $username = trim($_POST['username']);
		  $amount = trim($_POST['amount']);
		  	$sql = "INSERT INTO adminsell(username,amount)VALUES('{$username}','{$amount}')";
		  	$query = mysql_query($sql);
		  	if (empty($_POST["username"])) {
		  		echo "empty username";
		  	}else{
		  		$username =  trim($_POST['username']);

		  	}

		  	if (empty($_POST["amount"])) {
		  		echo "empty amount";
		  	}else{
		  		$amount =  trim($_POST['amount']);
		  		echo "<span style='color:teal'>Your account have been creadited successfully</span>";

		  	}


		  }
		?>

	<form class="form-signin" method="POST">
      <input type="txt" name="username" class="form-control" placeholder="Enter buyers username" required>
      <br>
      <p>
      	 <input type="txt" name="amount" class="form-control" placeholder="Enter buyers amount" required>
      <br>
      <p>
      	 <button type="submit" class="btn btn-success" name="submit">Buy</button>
      <br>
      <p>
	</form>
</center>
</body>
</html>
