<?php session_start();?>

<html>
<header>
</header>
 <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
<style>
body{
	background: teal;
}

.well{
	background: teal;
	text-align: center;
}
h6{
	color: yellow;
	 animation-name: example;
    animation-duration: 30s;
}
@keyframes example{
	0%{color: yellow;}
	25%{color: red;}
	50%{color: tomato;}
	100%{color: orange;}
	
}
</style>
<body>
	<div class="well well-sm">
     <h6>Wrong password/User Name check your login details</h6>
    </div>
    <?php
      session_start();
      session_unset();
	  session_destroy();
	  header("Refresh:3 url=../profitchain.com/login.html");
	exit;
    ?>
</body>
<html>