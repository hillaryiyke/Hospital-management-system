<?php
   session_start();
?>
<?php
   include_once'database.php';
?>
<?php
  $username = trim($_POST['username']);
  $firstname = trim($_POST['firstname']);
  $lastname = trim($_POST['lastname']);
  $email = trim($_POST['email']);
  $mobilenumber = trim($_POST['mobilenumber']);
  $bankname = trim($_POST['bankname']);
  $accountname = trim($_POST['accountname']);
  $accountnumber = trim($_POST['accountnumber']);
  $password = trim($_POST['password']);
  $password_confirmation = trim($_POST['password_confirmation']);

  if ($_POST) {
  	$sql = "INSERT INTO user(username,firstname,lastname,email,mobilenumber,bankname,accountname,accountnumber,password) 
  	     VALUES('$username','$firstname','$lastname','$email','$mobilenumber','$bankname','$accountname','$accountnumber','$password')";
  	$query = mysql_query($sql);
  	$res = mysql_num_rows($query);
  	while ($row = mysql_fetch_array($res) > 0) {
  		echo "sent";
  	}

  }
?>