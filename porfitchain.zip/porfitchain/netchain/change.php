
<div class="menu">
 <h4 class="jumbotron">DEBIT AND CREDITED MEMBER ACOUNT</h4>
  <li><a href="adminsell.php">Adminsell</a></li>
  <li><a href="security2.php">Admin Rejister</a></li>
  <li><a href="upadate.php">Admin login</a></li>
  <li><a href="change.php">Debit account</a></li>
  <li><a href="selectnetchainbuy.php">All bought netchain</a></li>


</div>
<p>
 <p>
<?php
  $id = $_REQUEST['id'];
  $newusername = $_REQUEST['newusername'];
  $newamount = $_REQUEST['newamount'];

  include_once 'database.php';

  mysql_query("UPDATE adminsell SET username='{$newusername}', amount='{$newamount}' WHERE id='$id'");
  echo "You values have been updated successfully";


?>