
<?php 
  session_start();
?>
<html>
<header>
  <title></title>
  <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/b4_sidebar.css">
    <link rel="stylesheet" href="../css/navbar-top-fixed.css">
    <link rel="stylesheet" href="../profitchain.com/css/custom.css">
    <link rel="stylesheet" href="../profitchain.com/css/signin.css">
</header>
<style>
   li {
    display: inline-block;
    background: 8px;
   }
   .menu{
    background: teal;
   }
   li a{
    color: white;
    margin: 8px;
   
   }
   a{
     text-decoration: none;
   }
   a:hover{
    background:tomato;
   }
   .jumbotron{
    background: yellow;
    color: white;
   }

</style>
<body>
  <center>
 <div class="menu">
  <h4 class="jumbotron">NETCHAIN BOUGHT BY THE USERS</h4>
   <li><a href="adminsell.php">Adminsell</a></li>
    <li><a href="upadate.php">Update users wallet</a></li>
    <li><a href="selectnetchainbuy.php">All bought netchain</a></li>
    <form id="logout-form" action="adminlogout.php" method="POST">
       <input type="hidden" name="submit" value=""> 
       <button type="submit" name="submit">Logout</button>
    </form>
 </div>
 <p>
  <p>
<?php
$id = $_POST['id'];
 $username = trim($_POST["username"]);
 $sellamount = trim($_POST["sellamount"]);
//Connect to database whenever the page loads
$con = mysqli_connect("localhost", "root", "", "netchaindatabase");
$sql = "SELECT * FROM buynetchain";
 $res = mysqli_query($con,$sql);
 echo "<table width=\'90%' align=center border=2>";
 echo "<tr><td widht=\'40%' align=center bgcolor=\'FFFF00\'>ID</td>
 <td width=\'40%' align=center bgcolor=\'FFFF00'>USERNAME</td>
    <td width=\'40%' align=center bgcolor=\'FFFF00'>SELLAMOUNT</td>
    <td width=\'40%' align=center bgcolor=\'FFFF00'>DATE</td>
    </tr>
 ";
 while ($row = mysqli_fetch_array($res)){
 
  $id = $row['id'];
  $username = $row['username'];
  $sellamount = $row['sellamount'];
    $date_time = strftime("%d-%m-%y %H:%M:%S", (time() - 3600));
   echo "<tr><td align=center>
       <a href=\"update2.php?ids=$id&usernames=$username&sellamounts=$sellamount&date_time=$date_time\">$id</a></td>
       <td>$username</td><td>$sellamount</td><td>$date_time</td>
   </tr>";
  }
 
?> 
</center>
</body>
</html>