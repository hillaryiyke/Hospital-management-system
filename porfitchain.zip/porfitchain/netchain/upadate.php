<?php 
  session_start();
?>

<html>
<header>
  <title></title>
  <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/b4_sidebar.css">
    <link rel="stylesheet" href="../css/navbar-top-fixed.css">
    <link rel="stylesheet" href="../profitchain.com/css/custom.css">
    <link rel="stylesheet" href="../profitchain.com/css/signin.css">
</header>
<style>
   li {
    display: inline-block;
    background: 8px;
   }
   .menu{
    background: teal;
   }
   li a{
    color: white;
    margin: 8px;
   
   }
   a{
     text-decoration: none;
   }
   a:hover{
    background:tomato;
   }
   .jumbotron{
    background: yellow;
    color: white;
   }

</style>
<body>
  <center>
 <div class="menu">
  <h4 class="jumbotron">UPDATE ALL MEMBERS</h4>
   <li><a href="adminsell.php">Adminsell</a></li>
    <li><a href="update2.php">Update users wallet</a></li>
    <li><a href="selectnetchainbuy.php">All bought netchain</a></li>
    <form id="logout-form" action="adminlogout.php" method="POST">
       <input type="hidden" name="submit" value=""> 
       <button type="submit" name="submit">Logout</button>
    </form>
 </div>
 <p>
  <p>
<?php
$id = $_POST['id'];
 $username = trim($_POST["username"]);
 $amount = trim($_POST["amount"]);
//Connect to database whenever the page loads
$con = mysqli_connect("localhost", "root", "", "netchaindatabase");
$sql = "SELECT * FROM adminsell";
 $res = mysqli_query($con,$sql);
 echo "<table width=\'90%' align=center border=2>";
 echo "<tr><td widht=\'40%' align=center bgcolor=\'FFFF00\'>ID</td>
 <td width=\'40%' align=center bgcolor=\'FFFF00'>USERNAME</td>
    <td width=\'40%' align=center bgcolor=\'FFFF00'>AMOUNT</td>
    </tr>
 ";
 while ($row = mysqli_fetch_array($res)){
 
  $id = $row['id'];
  $username = $row['username'];
  $amount = $row['amount'];
   
   echo "<tr><td align=center>
       <a href=\"update2.php?ids=$id&usernames=$username&amounts=$amount\">$id</a></td>
       <td>$username</td><td>$amount</td>
   </tr>";
  }
 
?> 
</center>
</body>
</html>