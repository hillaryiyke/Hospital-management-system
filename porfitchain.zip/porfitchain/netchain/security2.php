
   <?php

        session_start();
     ?>
    <?php
        include_once'database.php';
     ?>
<html>
<header>
</header>
   <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../profitchain.com/css/b4_sidebar.css">
    <link rel="stylesheet" href="../profitchain.com.com/css/navbar-top-fixed.css">
    <link rel="stylesheet" href="../profitchain.com/css/custom.css">
    <link rel="stylesheet" href="../profitchain.com/css/signin.css">
    <link rel="shortcut icon" href="img/img_20180612_wa0012_xZm_icon.ico" type="image/x-icon">
    <style>
       li {
        display: inline-block;
        background: 8px;
       }
       .menu{
        background: teal;
       }
       li a{
        color: white;
        margin: 8px;
       
       }
       a{
         text-decoration: none;
       }
       a:hover{
        background:tomato;
       }
       .jumbotron{
        background: yellow;
        color: white;
       }
       .font-weight-normal{
        color: teal;
       }

    </style>
<body>
  <center>
   <div class="menu">
     <h4 class="jumbotron">THIS PAGE IS MADE ONLY FOR ADMIN TO REGISTER</h4>
    </div>
    <p>
     <p>
     <?php
       $username = trim($_POST['username']);
       $password = trim($_POST['password']);
       
       if ($_POST) {
        if (empty($username)) {
          echo "empty username";
      }else{
        if (empty($password)) {
          echo "empty password";
        }else{
          $sql = "INSERT INTO admin(username,password)VALUES('{$username}','{$password}')";
        $query = mysql_query($sql);
       
      }
         }
       }
     ?>
  
   <form class="form-signin" method="POST" action="security2.php" aria-label="Login">

     <h1 class="text-center h3 mb-3 font-weight-normal">ADMIN SIGN UP</h1>
     <label for="inputEmail" class="sr-only">Username</label>
     <input type="text" id="username" class="form-control" name="username" value="" placeholder="Username" required autofocus>
           <label for="inputPassword" class="sr-only">Password</label>
     <input type="password" id="password" class="form-control" name="password" placeholder="Password" required>
           <div class="checkbox mb-3">
       <label>
         <input type="checkbox" name="remember" > Remember me
       </label>
     </div>
     <button class="btn btn-lg btn-success btn-block" type="submit">SIGN UP</button>
     <a class="btn btn-link" href="password/reset.html"> Forgot Your Password?</a>
     <a class="btn btn-link" href="security.php"> Admin login</a>
   </form>
   </center>
</body>
</html>