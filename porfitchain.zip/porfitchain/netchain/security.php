<?php session_start();?>

<html>
<header>
</header>
   <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/b4_sidebar.css">
    <link rel="stylesheet" href="css/navbar-top-fixed.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="../profitchcss/signin.css">
    <link rel="shortcut icon" href="img/img_20180612_wa0012_xZm_icon.ico" type="image/x-icon">
     
    <style>
       li {
        display: inline-block;
        background: 8px;
       }
       .menu{
        background: teal;
       }
       li a{
        color: white;
        margin: 8px;
       
       }
       a{
         text-decoration: none;
       }
       a:hover{
        background:tomato;
       }
       .jumbotron{
        background: yellow;
        color: white;
       }
       .font-weight-normal{
        color: teal;
       }

    </style>
<body>
  <center>
  <div class="menu">
   <div class="jumbotron">THIS PAGE IS MADE ONLY FOR ADMIN TO LOGIN </div>
   <li><a href="security2.php">Admin Registeration</a></li>
 </div>
<?php 
  session_start();
?>
<?php
   include_once'database.php';
?>
<?php
  $username = $_POST['username'];
  $password = $_POST['password'];
  if (empty($username)) {
    echo "Your username is required";
  }else{
    if (empty($password)) {
        echo "password is required";
    }else{
    $sql = "SELECT * FROM admin WHERE username = '{$username}' AND password = '{$password}'";
        $res = mysql_query($sql);
         if(mysql_fetch_row($res) > 0){
             /******************************/
             //Redirect to user page
             header("Location:../profitchain.com/data.php");
           }else{
            header("Location:erropage.php");
           }
    }
  }
  
 
?>
    
   <form class="" method="POST" action="security.php" aria-label="Login">

     <h1 class="text-center h3 mb-3 font-weight-normal">Sign In</h1>
     <label for="inputEmail" class="sr-only">Username</label>
     <input type="text" id="username" class="form-control" name="username" value="" placeholder="Username" required autofocus>
           <label for="inputPassword" class="sr-only">Password</label><br><p>
     <input type="password" id="password" class="form-control" name="password" placeholder="Password" required>
           <div class="checkbox mb-3">
       <label>
         <input type="checkbox" name="remember" > Remember me
       </label>
     </div>
     <button class="btn btn-lg btn-success btn-block" type="submit">Sign in</button>
     <a class="btn btn-link" href="password/reset.html"> Forgot Your Password?</a>
   </form>
</center>
</body>
</html>