<html>
<header>
    <title></title>
    <link href="../profitchain.com/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/b4_sidebar.css">
    <link rel="stylesheet" href="../css/navbar-top-fixed.css">
    <link rel="stylesheet" href="../profitchain.com/css/custom.css">
    <link rel="stylesheet" href="../profitchain.com/css/signin.css">
</header>
<style>
   li {
    display: inline-block;
    background: 8px;
   }
   .menu{
    background: teal;
   }
   li a{
    color: white;
    margin: 8px;
   
   }
   a{
     text-decoration: none;
   }
   a:hover{
    background:tomato;
   }
   .jumbotron{
    background: yellow;
    color: white;
   }

</style>
<body>
<center>
    <div class="menu">
     <h4 class="jumbotron">Update users wallet</h4>
      <li><a href="adminsell.php">Adminsell</a></li>
      <li><a href="upadate.php">User list of account</a></li>
    <li><a href="selectnetchainbuy.php">All bought netchain</a></li>
      <form id="logout-form" action="adminlogout.php" method="POST">
          <input type="hidden" name="submit" value=""> 
          <button type="submit" name="submit">Logout</button>
       </form>
    </div>
    <p>
     <p>
    <?php
    if ($_POST) {
       
   
      $id = $_REQUEST['id'];
      $newusername = $_REQUEST['newusername'];
      $newamount = $_REQUEST['newamount'];

      include_once 'database.php';
     $sql =  mysql_query("UPDATE adminsell SET username='{$newusername}', amount='{$newamount}' WHERE id='$id'");
     $res = mysql_query($sql);
    
      echo "You values have been updated successfully";
     
      
    }
    ?>
   <h4>UPADTE CLIENT WALLET:<?php echo $_REQUEST['username'];?> </h4>
    <form method="POST" action="update2.php">
    	<table border="0" width="60%">
    		<tr><td width="30%">USERMANE:</td><td><input type="text" name="newusername" 
    			value="<?php echo $_REQUEST['usernames'];?>"></td></tr>
    		<tr><td width="30%">AMOUNT:</td><td><input type="text" name="newamount" 
    			value="<?php echo $_REQUEST['amounts'];?>"></td></tr></table></p>
    	   <button type="submit">UPDATE AMOUNT</button>
    	   <input type="hidden" name="id" value="<?php echo $_REQUEST['ids'];?>">
      
    </form>
</center>
</body>
</html>