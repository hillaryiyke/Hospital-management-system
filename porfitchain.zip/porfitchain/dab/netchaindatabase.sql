-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2018 at 09:36 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `netchaindatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'santos', 'santos'),
(2, 'Uchenna22', 'Uchenna22##'),
(3, 'santos', 'santos'),
(4, 'santos', 'santos'),
(5, 'santos', 'santos'),
(6, 'santos', 'santos'),
(7, 'santos', 'santos'),
(8, 'santos', 'santos');

-- --------------------------------------------------------

--
-- Table structure for table `adminsell`
--

CREATE TABLE IF NOT EXISTS `adminsell` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminsell`
--

INSERT INTO `adminsell` (`id`, `username`, `amount`) VALUES
(1, 'Uchenna22', '8.00NC'),
(2, 'santos', '1nc');

-- --------------------------------------------------------

--
-- Table structure for table `buynetchain`
--

CREATE TABLE IF NOT EXISTS `buynetchain` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `sellamount` varchar(30) NOT NULL,
  `date_time` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buynetchain`
--

INSERT INTO `buynetchain` (`id`, `username`, `sellamount`, `date_time`) VALUES
(1, 'santos', '2nv', ''),
(2, 'Uchenna22', '8NC', ''),
(21, 'santos', '5nc', '14-09-18 07:42:39'),
(22, 'santos', '6', '14-09-18 08:02:00'),
(23, 'santos', '6', '14-09-18 08:07:29');

-- --------------------------------------------------------

--
-- Table structure for table `conver`
--

CREATE TABLE IF NOT EXISTS `conver` (
  `id` int(11) NOT NULL,
  `cryptocurrency` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `convert_unit` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conver`
--

INSERT INTO `conver` (`id`, `cryptocurrency`, `address`, `convert_unit`) VALUES
(12, 'btc', '23333rggufg', '6.00NC'),
(13, 'eth', 'ungfcj12234456', '6.00NC'),
(14, 'usd', '432ryhj9jnbvvn', '3nc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobilenumber` varchar(250) NOT NULL,
  `bankname` varchar(250) NOT NULL,
  `accountname` varchar(250) NOT NULL,
  `accountnumber` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `firstname`, `lastname`, `email`, `mobilenumber`, `bankname`, `accountname`, `accountnumber`, `password`) VALUES
(1, 'username', 'firstname', 'lastname', 'email', 'mobilenumber', 'bankname', 'accountname', 'accountnumber', 'password'),
(2, 'santos', 'hillary', 'iyke', 'hillaryhillaryiyke@gmial.com', '07064562237', 'Eco Bank', 'nwabueze hillary i', '4611179062', 'hillary'),
(3, 'santos', 'hillary', 'iyke', 'hillaryhillaryiyke@gmial.com', '07064562237', 'Eco Bank', 'nwabueze hillary i', '4611179062', 'santos'),
(4, 'Uchenna22', 'Onyeji', 'austine', 'fabkid0@gmail.com', '08039684983', 'Diamond Bank', 'onyeji uchenna', '0029524838', 'uchenna');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminsell`
--
ALTER TABLE `adminsell`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buynetchain`
--
ALTER TABLE `buynetchain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conver`
--
ALTER TABLE `conver`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `adminsell`
--
ALTER TABLE `adminsell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `buynetchain`
--
ALTER TABLE `buynetchain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `conver`
--
ALTER TABLE `conver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
